import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
/**
 * Model CartItem
 *
 */
export type CartItemModel = runtime.Types.Result.DefaultSelection<Prisma.$CartItemPayload>;
export type AggregateCartItem = {
    _count: CartItemCountAggregateOutputType | null;
    _avg: CartItemAvgAggregateOutputType | null;
    _sum: CartItemSumAggregateOutputType | null;
    _min: CartItemMinAggregateOutputType | null;
    _max: CartItemMaxAggregateOutputType | null;
};
export type CartItemAvgAggregateOutputType = {
    quantity: number | null;
};
export type CartItemSumAggregateOutputType = {
    quantity: number | null;
};
export type CartItemMinAggregateOutputType = {
    id: string | null;
    cartId: string | null;
    menuItemId: string | null;
    quantity: number | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type CartItemMaxAggregateOutputType = {
    id: string | null;
    cartId: string | null;
    menuItemId: string | null;
    quantity: number | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type CartItemCountAggregateOutputType = {
    id: number;
    cartId: number;
    menuItemId: number;
    quantity: number;
    createdAt: number;
    updatedAt: number;
    _all: number;
};
export type CartItemAvgAggregateInputType = {
    quantity?: true;
};
export type CartItemSumAggregateInputType = {
    quantity?: true;
};
export type CartItemMinAggregateInputType = {
    id?: true;
    cartId?: true;
    menuItemId?: true;
    quantity?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type CartItemMaxAggregateInputType = {
    id?: true;
    cartId?: true;
    menuItemId?: true;
    quantity?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type CartItemCountAggregateInputType = {
    id?: true;
    cartId?: true;
    menuItemId?: true;
    quantity?: true;
    createdAt?: true;
    updatedAt?: true;
    _all?: true;
};
export type CartItemAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which CartItem to aggregate.
     */
    where?: Prisma.CartItemWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of CartItems to fetch.
     */
    orderBy?: Prisma.CartItemOrderByWithRelationInput | Prisma.CartItemOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the start position
     */
    cursor?: Prisma.CartItemWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` CartItems from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` CartItems.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Count returned CartItems
    **/
    _count?: true | CartItemCountAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to average
    **/
    _avg?: CartItemAvgAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to sum
    **/
    _sum?: CartItemSumAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the minimum value
    **/
    _min?: CartItemMinAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the maximum value
    **/
    _max?: CartItemMaxAggregateInputType;
};
export type GetCartItemAggregateType<T extends CartItemAggregateArgs> = {
    [P in keyof T & keyof AggregateCartItem]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateCartItem[P]> : Prisma.GetScalarType<T[P], AggregateCartItem[P]>;
};
export type CartItemGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.CartItemWhereInput;
    orderBy?: Prisma.CartItemOrderByWithAggregationInput | Prisma.CartItemOrderByWithAggregationInput[];
    by: Prisma.CartItemScalarFieldEnum[] | Prisma.CartItemScalarFieldEnum;
    having?: Prisma.CartItemScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: CartItemCountAggregateInputType | true;
    _avg?: CartItemAvgAggregateInputType;
    _sum?: CartItemSumAggregateInputType;
    _min?: CartItemMinAggregateInputType;
    _max?: CartItemMaxAggregateInputType;
};
export type CartItemGroupByOutputType = {
    id: string;
    cartId: string;
    menuItemId: string;
    quantity: number;
    createdAt: Date;
    updatedAt: Date;
    _count: CartItemCountAggregateOutputType | null;
    _avg: CartItemAvgAggregateOutputType | null;
    _sum: CartItemSumAggregateOutputType | null;
    _min: CartItemMinAggregateOutputType | null;
    _max: CartItemMaxAggregateOutputType | null;
};
export type GetCartItemGroupByPayload<T extends CartItemGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<CartItemGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof CartItemGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], CartItemGroupByOutputType[P]> : Prisma.GetScalarType<T[P], CartItemGroupByOutputType[P]>;
}>>;
export type CartItemWhereInput = {
    AND?: Prisma.CartItemWhereInput | Prisma.CartItemWhereInput[];
    OR?: Prisma.CartItemWhereInput[];
    NOT?: Prisma.CartItemWhereInput | Prisma.CartItemWhereInput[];
    id?: Prisma.StringFilter<"CartItem"> | string;
    cartId?: Prisma.StringFilter<"CartItem"> | string;
    menuItemId?: Prisma.StringFilter<"CartItem"> | string;
    quantity?: Prisma.IntFilter<"CartItem"> | number;
    createdAt?: Prisma.DateTimeFilter<"CartItem"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"CartItem"> | Date | string;
    cart?: Prisma.XOR<Prisma.CartScalarRelationFilter, Prisma.CartWhereInput>;
    menuItem?: Prisma.XOR<Prisma.MenuItemScalarRelationFilter, Prisma.MenuItemWhereInput>;
};
export type CartItemOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    cartId?: Prisma.SortOrder;
    menuItemId?: Prisma.SortOrder;
    quantity?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    cart?: Prisma.CartOrderByWithRelationInput;
    menuItem?: Prisma.MenuItemOrderByWithRelationInput;
};
export type CartItemWhereUniqueInput = Prisma.AtLeast<{
    id?: string;
    cartId_menuItemId?: Prisma.CartItemCartIdMenuItemIdCompoundUniqueInput;
    AND?: Prisma.CartItemWhereInput | Prisma.CartItemWhereInput[];
    OR?: Prisma.CartItemWhereInput[];
    NOT?: Prisma.CartItemWhereInput | Prisma.CartItemWhereInput[];
    cartId?: Prisma.StringFilter<"CartItem"> | string;
    menuItemId?: Prisma.StringFilter<"CartItem"> | string;
    quantity?: Prisma.IntFilter<"CartItem"> | number;
    createdAt?: Prisma.DateTimeFilter<"CartItem"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"CartItem"> | Date | string;
    cart?: Prisma.XOR<Prisma.CartScalarRelationFilter, Prisma.CartWhereInput>;
    menuItem?: Prisma.XOR<Prisma.MenuItemScalarRelationFilter, Prisma.MenuItemWhereInput>;
}, "id" | "cartId_menuItemId">;
export type CartItemOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    cartId?: Prisma.SortOrder;
    menuItemId?: Prisma.SortOrder;
    quantity?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    _count?: Prisma.CartItemCountOrderByAggregateInput;
    _avg?: Prisma.CartItemAvgOrderByAggregateInput;
    _max?: Prisma.CartItemMaxOrderByAggregateInput;
    _min?: Prisma.CartItemMinOrderByAggregateInput;
    _sum?: Prisma.CartItemSumOrderByAggregateInput;
};
export type CartItemScalarWhereWithAggregatesInput = {
    AND?: Prisma.CartItemScalarWhereWithAggregatesInput | Prisma.CartItemScalarWhereWithAggregatesInput[];
    OR?: Prisma.CartItemScalarWhereWithAggregatesInput[];
    NOT?: Prisma.CartItemScalarWhereWithAggregatesInput | Prisma.CartItemScalarWhereWithAggregatesInput[];
    id?: Prisma.StringWithAggregatesFilter<"CartItem"> | string;
    cartId?: Prisma.StringWithAggregatesFilter<"CartItem"> | string;
    menuItemId?: Prisma.StringWithAggregatesFilter<"CartItem"> | string;
    quantity?: Prisma.IntWithAggregatesFilter<"CartItem"> | number;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"CartItem"> | Date | string;
    updatedAt?: Prisma.DateTimeWithAggregatesFilter<"CartItem"> | Date | string;
};
export type CartItemCreateInput = {
    id?: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    cart: Prisma.CartCreateNestedOneWithoutItemsInput;
    menuItem: Prisma.MenuItemCreateNestedOneWithoutCartItemsInput;
};
export type CartItemUncheckedCreateInput = {
    id?: string;
    cartId: string;
    menuItemId: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type CartItemUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    cart?: Prisma.CartUpdateOneRequiredWithoutItemsNestedInput;
    menuItem?: Prisma.MenuItemUpdateOneRequiredWithoutCartItemsNestedInput;
};
export type CartItemUncheckedUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    cartId?: Prisma.StringFieldUpdateOperationsInput | string;
    menuItemId?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type CartItemCreateManyInput = {
    id?: string;
    cartId: string;
    menuItemId: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type CartItemUpdateManyMutationInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type CartItemUncheckedUpdateManyInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    cartId?: Prisma.StringFieldUpdateOperationsInput | string;
    menuItemId?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type CartItemListRelationFilter = {
    every?: Prisma.CartItemWhereInput;
    some?: Prisma.CartItemWhereInput;
    none?: Prisma.CartItemWhereInput;
};
export type CartItemOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type CartItemCartIdMenuItemIdCompoundUniqueInput = {
    cartId: string;
    menuItemId: string;
};
export type CartItemCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    cartId?: Prisma.SortOrder;
    menuItemId?: Prisma.SortOrder;
    quantity?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type CartItemAvgOrderByAggregateInput = {
    quantity?: Prisma.SortOrder;
};
export type CartItemMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    cartId?: Prisma.SortOrder;
    menuItemId?: Prisma.SortOrder;
    quantity?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type CartItemMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    cartId?: Prisma.SortOrder;
    menuItemId?: Prisma.SortOrder;
    quantity?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type CartItemSumOrderByAggregateInput = {
    quantity?: Prisma.SortOrder;
};
export type CartItemCreateNestedManyWithoutMenuItemInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutMenuItemInput, Prisma.CartItemUncheckedCreateWithoutMenuItemInput> | Prisma.CartItemCreateWithoutMenuItemInput[] | Prisma.CartItemUncheckedCreateWithoutMenuItemInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutMenuItemInput | Prisma.CartItemCreateOrConnectWithoutMenuItemInput[];
    createMany?: Prisma.CartItemCreateManyMenuItemInputEnvelope;
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
};
export type CartItemUncheckedCreateNestedManyWithoutMenuItemInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutMenuItemInput, Prisma.CartItemUncheckedCreateWithoutMenuItemInput> | Prisma.CartItemCreateWithoutMenuItemInput[] | Prisma.CartItemUncheckedCreateWithoutMenuItemInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutMenuItemInput | Prisma.CartItemCreateOrConnectWithoutMenuItemInput[];
    createMany?: Prisma.CartItemCreateManyMenuItemInputEnvelope;
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
};
export type CartItemUpdateManyWithoutMenuItemNestedInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutMenuItemInput, Prisma.CartItemUncheckedCreateWithoutMenuItemInput> | Prisma.CartItemCreateWithoutMenuItemInput[] | Prisma.CartItemUncheckedCreateWithoutMenuItemInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutMenuItemInput | Prisma.CartItemCreateOrConnectWithoutMenuItemInput[];
    upsert?: Prisma.CartItemUpsertWithWhereUniqueWithoutMenuItemInput | Prisma.CartItemUpsertWithWhereUniqueWithoutMenuItemInput[];
    createMany?: Prisma.CartItemCreateManyMenuItemInputEnvelope;
    set?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    disconnect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    delete?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    update?: Prisma.CartItemUpdateWithWhereUniqueWithoutMenuItemInput | Prisma.CartItemUpdateWithWhereUniqueWithoutMenuItemInput[];
    updateMany?: Prisma.CartItemUpdateManyWithWhereWithoutMenuItemInput | Prisma.CartItemUpdateManyWithWhereWithoutMenuItemInput[];
    deleteMany?: Prisma.CartItemScalarWhereInput | Prisma.CartItemScalarWhereInput[];
};
export type CartItemUncheckedUpdateManyWithoutMenuItemNestedInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutMenuItemInput, Prisma.CartItemUncheckedCreateWithoutMenuItemInput> | Prisma.CartItemCreateWithoutMenuItemInput[] | Prisma.CartItemUncheckedCreateWithoutMenuItemInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutMenuItemInput | Prisma.CartItemCreateOrConnectWithoutMenuItemInput[];
    upsert?: Prisma.CartItemUpsertWithWhereUniqueWithoutMenuItemInput | Prisma.CartItemUpsertWithWhereUniqueWithoutMenuItemInput[];
    createMany?: Prisma.CartItemCreateManyMenuItemInputEnvelope;
    set?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    disconnect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    delete?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    update?: Prisma.CartItemUpdateWithWhereUniqueWithoutMenuItemInput | Prisma.CartItemUpdateWithWhereUniqueWithoutMenuItemInput[];
    updateMany?: Prisma.CartItemUpdateManyWithWhereWithoutMenuItemInput | Prisma.CartItemUpdateManyWithWhereWithoutMenuItemInput[];
    deleteMany?: Prisma.CartItemScalarWhereInput | Prisma.CartItemScalarWhereInput[];
};
export type CartItemCreateNestedManyWithoutCartInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutCartInput, Prisma.CartItemUncheckedCreateWithoutCartInput> | Prisma.CartItemCreateWithoutCartInput[] | Prisma.CartItemUncheckedCreateWithoutCartInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutCartInput | Prisma.CartItemCreateOrConnectWithoutCartInput[];
    createMany?: Prisma.CartItemCreateManyCartInputEnvelope;
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
};
export type CartItemUncheckedCreateNestedManyWithoutCartInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutCartInput, Prisma.CartItemUncheckedCreateWithoutCartInput> | Prisma.CartItemCreateWithoutCartInput[] | Prisma.CartItemUncheckedCreateWithoutCartInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutCartInput | Prisma.CartItemCreateOrConnectWithoutCartInput[];
    createMany?: Prisma.CartItemCreateManyCartInputEnvelope;
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
};
export type CartItemUpdateManyWithoutCartNestedInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutCartInput, Prisma.CartItemUncheckedCreateWithoutCartInput> | Prisma.CartItemCreateWithoutCartInput[] | Prisma.CartItemUncheckedCreateWithoutCartInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutCartInput | Prisma.CartItemCreateOrConnectWithoutCartInput[];
    upsert?: Prisma.CartItemUpsertWithWhereUniqueWithoutCartInput | Prisma.CartItemUpsertWithWhereUniqueWithoutCartInput[];
    createMany?: Prisma.CartItemCreateManyCartInputEnvelope;
    set?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    disconnect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    delete?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    update?: Prisma.CartItemUpdateWithWhereUniqueWithoutCartInput | Prisma.CartItemUpdateWithWhereUniqueWithoutCartInput[];
    updateMany?: Prisma.CartItemUpdateManyWithWhereWithoutCartInput | Prisma.CartItemUpdateManyWithWhereWithoutCartInput[];
    deleteMany?: Prisma.CartItemScalarWhereInput | Prisma.CartItemScalarWhereInput[];
};
export type CartItemUncheckedUpdateManyWithoutCartNestedInput = {
    create?: Prisma.XOR<Prisma.CartItemCreateWithoutCartInput, Prisma.CartItemUncheckedCreateWithoutCartInput> | Prisma.CartItemCreateWithoutCartInput[] | Prisma.CartItemUncheckedCreateWithoutCartInput[];
    connectOrCreate?: Prisma.CartItemCreateOrConnectWithoutCartInput | Prisma.CartItemCreateOrConnectWithoutCartInput[];
    upsert?: Prisma.CartItemUpsertWithWhereUniqueWithoutCartInput | Prisma.CartItemUpsertWithWhereUniqueWithoutCartInput[];
    createMany?: Prisma.CartItemCreateManyCartInputEnvelope;
    set?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    disconnect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    delete?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    connect?: Prisma.CartItemWhereUniqueInput | Prisma.CartItemWhereUniqueInput[];
    update?: Prisma.CartItemUpdateWithWhereUniqueWithoutCartInput | Prisma.CartItemUpdateWithWhereUniqueWithoutCartInput[];
    updateMany?: Prisma.CartItemUpdateManyWithWhereWithoutCartInput | Prisma.CartItemUpdateManyWithWhereWithoutCartInput[];
    deleteMany?: Prisma.CartItemScalarWhereInput | Prisma.CartItemScalarWhereInput[];
};
export type CartItemCreateWithoutMenuItemInput = {
    id?: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    cart: Prisma.CartCreateNestedOneWithoutItemsInput;
};
export type CartItemUncheckedCreateWithoutMenuItemInput = {
    id?: string;
    cartId: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type CartItemCreateOrConnectWithoutMenuItemInput = {
    where: Prisma.CartItemWhereUniqueInput;
    create: Prisma.XOR<Prisma.CartItemCreateWithoutMenuItemInput, Prisma.CartItemUncheckedCreateWithoutMenuItemInput>;
};
export type CartItemCreateManyMenuItemInputEnvelope = {
    data: Prisma.CartItemCreateManyMenuItemInput | Prisma.CartItemCreateManyMenuItemInput[];
    skipDuplicates?: boolean;
};
export type CartItemUpsertWithWhereUniqueWithoutMenuItemInput = {
    where: Prisma.CartItemWhereUniqueInput;
    update: Prisma.XOR<Prisma.CartItemUpdateWithoutMenuItemInput, Prisma.CartItemUncheckedUpdateWithoutMenuItemInput>;
    create: Prisma.XOR<Prisma.CartItemCreateWithoutMenuItemInput, Prisma.CartItemUncheckedCreateWithoutMenuItemInput>;
};
export type CartItemUpdateWithWhereUniqueWithoutMenuItemInput = {
    where: Prisma.CartItemWhereUniqueInput;
    data: Prisma.XOR<Prisma.CartItemUpdateWithoutMenuItemInput, Prisma.CartItemUncheckedUpdateWithoutMenuItemInput>;
};
export type CartItemUpdateManyWithWhereWithoutMenuItemInput = {
    where: Prisma.CartItemScalarWhereInput;
    data: Prisma.XOR<Prisma.CartItemUpdateManyMutationInput, Prisma.CartItemUncheckedUpdateManyWithoutMenuItemInput>;
};
export type CartItemScalarWhereInput = {
    AND?: Prisma.CartItemScalarWhereInput | Prisma.CartItemScalarWhereInput[];
    OR?: Prisma.CartItemScalarWhereInput[];
    NOT?: Prisma.CartItemScalarWhereInput | Prisma.CartItemScalarWhereInput[];
    id?: Prisma.StringFilter<"CartItem"> | string;
    cartId?: Prisma.StringFilter<"CartItem"> | string;
    menuItemId?: Prisma.StringFilter<"CartItem"> | string;
    quantity?: Prisma.IntFilter<"CartItem"> | number;
    createdAt?: Prisma.DateTimeFilter<"CartItem"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"CartItem"> | Date | string;
};
export type CartItemCreateWithoutCartInput = {
    id?: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    menuItem: Prisma.MenuItemCreateNestedOneWithoutCartItemsInput;
};
export type CartItemUncheckedCreateWithoutCartInput = {
    id?: string;
    menuItemId: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type CartItemCreateOrConnectWithoutCartInput = {
    where: Prisma.CartItemWhereUniqueInput;
    create: Prisma.XOR<Prisma.CartItemCreateWithoutCartInput, Prisma.CartItemUncheckedCreateWithoutCartInput>;
};
export type CartItemCreateManyCartInputEnvelope = {
    data: Prisma.CartItemCreateManyCartInput | Prisma.CartItemCreateManyCartInput[];
    skipDuplicates?: boolean;
};
export type CartItemUpsertWithWhereUniqueWithoutCartInput = {
    where: Prisma.CartItemWhereUniqueInput;
    update: Prisma.XOR<Prisma.CartItemUpdateWithoutCartInput, Prisma.CartItemUncheckedUpdateWithoutCartInput>;
    create: Prisma.XOR<Prisma.CartItemCreateWithoutCartInput, Prisma.CartItemUncheckedCreateWithoutCartInput>;
};
export type CartItemUpdateWithWhereUniqueWithoutCartInput = {
    where: Prisma.CartItemWhereUniqueInput;
    data: Prisma.XOR<Prisma.CartItemUpdateWithoutCartInput, Prisma.CartItemUncheckedUpdateWithoutCartInput>;
};
export type CartItemUpdateManyWithWhereWithoutCartInput = {
    where: Prisma.CartItemScalarWhereInput;
    data: Prisma.XOR<Prisma.CartItemUpdateManyMutationInput, Prisma.CartItemUncheckedUpdateManyWithoutCartInput>;
};
export type CartItemCreateManyMenuItemInput = {
    id?: string;
    cartId: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type CartItemUpdateWithoutMenuItemInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    cart?: Prisma.CartUpdateOneRequiredWithoutItemsNestedInput;
};
export type CartItemUncheckedUpdateWithoutMenuItemInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    cartId?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type CartItemUncheckedUpdateManyWithoutMenuItemInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    cartId?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type CartItemCreateManyCartInput = {
    id?: string;
    menuItemId: string;
    quantity: number;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type CartItemUpdateWithoutCartInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    menuItem?: Prisma.MenuItemUpdateOneRequiredWithoutCartItemsNestedInput;
};
export type CartItemUncheckedUpdateWithoutCartInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    menuItemId?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type CartItemUncheckedUpdateManyWithoutCartInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    menuItemId?: Prisma.StringFieldUpdateOperationsInput | string;
    quantity?: Prisma.IntFieldUpdateOperationsInput | number;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type CartItemSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    cartId?: boolean;
    menuItemId?: boolean;
    quantity?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    cart?: boolean | Prisma.CartDefaultArgs<ExtArgs>;
    menuItem?: boolean | Prisma.MenuItemDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["cartItem"]>;
export type CartItemSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    cartId?: boolean;
    menuItemId?: boolean;
    quantity?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    cart?: boolean | Prisma.CartDefaultArgs<ExtArgs>;
    menuItem?: boolean | Prisma.MenuItemDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["cartItem"]>;
export type CartItemSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    cartId?: boolean;
    menuItemId?: boolean;
    quantity?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    cart?: boolean | Prisma.CartDefaultArgs<ExtArgs>;
    menuItem?: boolean | Prisma.MenuItemDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["cartItem"]>;
export type CartItemSelectScalar = {
    id?: boolean;
    cartId?: boolean;
    menuItemId?: boolean;
    quantity?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
};
export type CartItemOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "cartId" | "menuItemId" | "quantity" | "createdAt" | "updatedAt", ExtArgs["result"]["cartItem"]>;
export type CartItemInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    cart?: boolean | Prisma.CartDefaultArgs<ExtArgs>;
    menuItem?: boolean | Prisma.MenuItemDefaultArgs<ExtArgs>;
};
export type CartItemIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    cart?: boolean | Prisma.CartDefaultArgs<ExtArgs>;
    menuItem?: boolean | Prisma.MenuItemDefaultArgs<ExtArgs>;
};
export type CartItemIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    cart?: boolean | Prisma.CartDefaultArgs<ExtArgs>;
    menuItem?: boolean | Prisma.MenuItemDefaultArgs<ExtArgs>;
};
export type $CartItemPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "CartItem";
    objects: {
        cart: Prisma.$CartPayload<ExtArgs>;
        menuItem: Prisma.$MenuItemPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: string;
        cartId: string;
        menuItemId: string;
        quantity: number;
        createdAt: Date;
        updatedAt: Date;
    }, ExtArgs["result"]["cartItem"]>;
    composites: {};
};
export type CartItemGetPayload<S extends boolean | null | undefined | CartItemDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$CartItemPayload, S>;
export type CartItemCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<CartItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: CartItemCountAggregateInputType | true;
};
export interface CartItemDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['CartItem'];
        meta: {
            name: 'CartItem';
        };
    };
    /**
     * Find zero or one CartItem that matches the filter.
     * @param {CartItemFindUniqueArgs} args - Arguments to find a CartItem
     * @example
     * // Get one CartItem
     * const cartItem = await prisma.cartItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends CartItemFindUniqueArgs>(args: Prisma.SelectSubset<T, CartItemFindUniqueArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find one CartItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {CartItemFindUniqueOrThrowArgs} args - Arguments to find a CartItem
     * @example
     * // Get one CartItem
     * const cartItem = await prisma.cartItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends CartItemFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, CartItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first CartItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CartItemFindFirstArgs} args - Arguments to find a CartItem
     * @example
     * // Get one CartItem
     * const cartItem = await prisma.cartItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends CartItemFindFirstArgs>(args?: Prisma.SelectSubset<T, CartItemFindFirstArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first CartItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CartItemFindFirstOrThrowArgs} args - Arguments to find a CartItem
     * @example
     * // Get one CartItem
     * const cartItem = await prisma.cartItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends CartItemFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, CartItemFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find zero or more CartItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CartItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all CartItems
     * const cartItems = await prisma.cartItem.findMany()
     *
     * // Get first 10 CartItems
     * const cartItems = await prisma.cartItem.findMany({ take: 10 })
     *
     * // Only select the `id`
     * const cartItemWithIdOnly = await prisma.cartItem.findMany({ select: { id: true } })
     *
     */
    findMany<T extends CartItemFindManyArgs>(args?: Prisma.SelectSubset<T, CartItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    /**
     * Create a CartItem.
     * @param {CartItemCreateArgs} args - Arguments to create a CartItem.
     * @example
     * // Create one CartItem
     * const CartItem = await prisma.cartItem.create({
     *   data: {
     *     // ... data to create a CartItem
     *   }
     * })
     *
     */
    create<T extends CartItemCreateArgs>(args: Prisma.SelectSubset<T, CartItemCreateArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Create many CartItems.
     * @param {CartItemCreateManyArgs} args - Arguments to create many CartItems.
     * @example
     * // Create many CartItems
     * const cartItem = await prisma.cartItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     */
    createMany<T extends CartItemCreateManyArgs>(args?: Prisma.SelectSubset<T, CartItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Create many CartItems and returns the data saved in the database.
     * @param {CartItemCreateManyAndReturnArgs} args - Arguments to create many CartItems.
     * @example
     * // Create many CartItems
     * const cartItem = await prisma.cartItem.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Create many CartItems and only return the `id`
     * const cartItemWithIdOnly = await prisma.cartItem.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    createManyAndReturn<T extends CartItemCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, CartItemCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    /**
     * Delete a CartItem.
     * @param {CartItemDeleteArgs} args - Arguments to delete one CartItem.
     * @example
     * // Delete one CartItem
     * const CartItem = await prisma.cartItem.delete({
     *   where: {
     *     // ... filter to delete one CartItem
     *   }
     * })
     *
     */
    delete<T extends CartItemDeleteArgs>(args: Prisma.SelectSubset<T, CartItemDeleteArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Update one CartItem.
     * @param {CartItemUpdateArgs} args - Arguments to update one CartItem.
     * @example
     * // Update one CartItem
     * const cartItem = await prisma.cartItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    update<T extends CartItemUpdateArgs>(args: Prisma.SelectSubset<T, CartItemUpdateArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Delete zero or more CartItems.
     * @param {CartItemDeleteManyArgs} args - Arguments to filter CartItems to delete.
     * @example
     * // Delete a few CartItems
     * const { count } = await prisma.cartItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     *
     */
    deleteMany<T extends CartItemDeleteManyArgs>(args?: Prisma.SelectSubset<T, CartItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more CartItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CartItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many CartItems
     * const cartItem = await prisma.cartItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    updateMany<T extends CartItemUpdateManyArgs>(args: Prisma.SelectSubset<T, CartItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more CartItems and returns the data updated in the database.
     * @param {CartItemUpdateManyAndReturnArgs} args - Arguments to update many CartItems.
     * @example
     * // Update many CartItems
     * const cartItem = await prisma.cartItem.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Update zero or more CartItems and only return the `id`
     * const cartItemWithIdOnly = await prisma.cartItem.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    updateManyAndReturn<T extends CartItemUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, CartItemUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    /**
     * Create or update one CartItem.
     * @param {CartItemUpsertArgs} args - Arguments to update or create a CartItem.
     * @example
     * // Update or create a CartItem
     * const cartItem = await prisma.cartItem.upsert({
     *   create: {
     *     // ... data to create a CartItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the CartItem we want to update
     *   }
     * })
     */
    upsert<T extends CartItemUpsertArgs>(args: Prisma.SelectSubset<T, CartItemUpsertArgs<ExtArgs>>): Prisma.Prisma__CartItemClient<runtime.Types.Result.GetResult<Prisma.$CartItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Count the number of CartItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CartItemCountArgs} args - Arguments to filter CartItems to count.
     * @example
     * // Count the number of CartItems
     * const count = await prisma.cartItem.count({
     *   where: {
     *     // ... the filter for the CartItems we want to count
     *   }
     * })
    **/
    count<T extends CartItemCountArgs>(args?: Prisma.Subset<T, CartItemCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], CartItemCountAggregateOutputType> : number>;
    /**
     * Allows you to perform aggregations operations on a CartItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CartItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends CartItemAggregateArgs>(args: Prisma.Subset<T, CartItemAggregateArgs>): Prisma.PrismaPromise<GetCartItemAggregateType<T>>;
    /**
     * Group by CartItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {CartItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     *
    **/
    groupBy<T extends CartItemGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: CartItemGroupByArgs['orderBy'];
    } : {
        orderBy?: CartItemGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, CartItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCartItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    /**
     * Fields of the CartItem model
     */
    readonly fields: CartItemFieldRefs;
}
/**
 * The delegate class that acts as a "Promise-like" for CartItem.
 * Why is this prefixed with `Prisma__`?
 * Because we want to prevent naming conflicts as mentioned in
 * https://github.com/prisma/prisma-client-js/issues/707
 */
export interface Prisma__CartItemClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    cart<T extends Prisma.CartDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.CartDefaultArgs<ExtArgs>>): Prisma.Prisma__CartClient<runtime.Types.Result.GetResult<Prisma.$CartPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    menuItem<T extends Prisma.MenuItemDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.MenuItemDefaultArgs<ExtArgs>>): Prisma.Prisma__MenuItemClient<runtime.Types.Result.GetResult<Prisma.$MenuItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
/**
 * Fields of the CartItem model
 */
export interface CartItemFieldRefs {
    readonly id: Prisma.FieldRef<"CartItem", 'String'>;
    readonly cartId: Prisma.FieldRef<"CartItem", 'String'>;
    readonly menuItemId: Prisma.FieldRef<"CartItem", 'String'>;
    readonly quantity: Prisma.FieldRef<"CartItem", 'Int'>;
    readonly createdAt: Prisma.FieldRef<"CartItem", 'DateTime'>;
    readonly updatedAt: Prisma.FieldRef<"CartItem", 'DateTime'>;
}
/**
 * CartItem findUnique
 */
export type CartItemFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * Filter, which CartItem to fetch.
     */
    where: Prisma.CartItemWhereUniqueInput;
};
/**
 * CartItem findUniqueOrThrow
 */
export type CartItemFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * Filter, which CartItem to fetch.
     */
    where: Prisma.CartItemWhereUniqueInput;
};
/**
 * CartItem findFirst
 */
export type CartItemFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * Filter, which CartItem to fetch.
     */
    where?: Prisma.CartItemWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of CartItems to fetch.
     */
    orderBy?: Prisma.CartItemOrderByWithRelationInput | Prisma.CartItemOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for CartItems.
     */
    cursor?: Prisma.CartItemWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` CartItems from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` CartItems.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of CartItems.
     */
    distinct?: Prisma.CartItemScalarFieldEnum | Prisma.CartItemScalarFieldEnum[];
};
/**
 * CartItem findFirstOrThrow
 */
export type CartItemFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * Filter, which CartItem to fetch.
     */
    where?: Prisma.CartItemWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of CartItems to fetch.
     */
    orderBy?: Prisma.CartItemOrderByWithRelationInput | Prisma.CartItemOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for CartItems.
     */
    cursor?: Prisma.CartItemWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` CartItems from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` CartItems.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of CartItems.
     */
    distinct?: Prisma.CartItemScalarFieldEnum | Prisma.CartItemScalarFieldEnum[];
};
/**
 * CartItem findMany
 */
export type CartItemFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * Filter, which CartItems to fetch.
     */
    where?: Prisma.CartItemWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of CartItems to fetch.
     */
    orderBy?: Prisma.CartItemOrderByWithRelationInput | Prisma.CartItemOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for listing CartItems.
     */
    cursor?: Prisma.CartItemWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` CartItems from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` CartItems.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of CartItems.
     */
    distinct?: Prisma.CartItemScalarFieldEnum | Prisma.CartItemScalarFieldEnum[];
};
/**
 * CartItem create
 */
export type CartItemCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * The data needed to create a CartItem.
     */
    data: Prisma.XOR<Prisma.CartItemCreateInput, Prisma.CartItemUncheckedCreateInput>;
};
/**
 * CartItem createMany
 */
export type CartItemCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to create many CartItems.
     */
    data: Prisma.CartItemCreateManyInput | Prisma.CartItemCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * CartItem createManyAndReturn
 */
export type CartItemCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelectCreateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * The data used to create many CartItems.
     */
    data: Prisma.CartItemCreateManyInput | Prisma.CartItemCreateManyInput[];
    skipDuplicates?: boolean;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemIncludeCreateManyAndReturn<ExtArgs> | null;
};
/**
 * CartItem update
 */
export type CartItemUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * The data needed to update a CartItem.
     */
    data: Prisma.XOR<Prisma.CartItemUpdateInput, Prisma.CartItemUncheckedUpdateInput>;
    /**
     * Choose, which CartItem to update.
     */
    where: Prisma.CartItemWhereUniqueInput;
};
/**
 * CartItem updateMany
 */
export type CartItemUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to update CartItems.
     */
    data: Prisma.XOR<Prisma.CartItemUpdateManyMutationInput, Prisma.CartItemUncheckedUpdateManyInput>;
    /**
     * Filter which CartItems to update
     */
    where?: Prisma.CartItemWhereInput;
    /**
     * Limit how many CartItems to update.
     */
    limit?: number;
};
/**
 * CartItem updateManyAndReturn
 */
export type CartItemUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelectUpdateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * The data used to update CartItems.
     */
    data: Prisma.XOR<Prisma.CartItemUpdateManyMutationInput, Prisma.CartItemUncheckedUpdateManyInput>;
    /**
     * Filter which CartItems to update
     */
    where?: Prisma.CartItemWhereInput;
    /**
     * Limit how many CartItems to update.
     */
    limit?: number;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemIncludeUpdateManyAndReturn<ExtArgs> | null;
};
/**
 * CartItem upsert
 */
export type CartItemUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * The filter to search for the CartItem to update in case it exists.
     */
    where: Prisma.CartItemWhereUniqueInput;
    /**
     * In case the CartItem found by the `where` argument doesn't exist, create a new CartItem with this data.
     */
    create: Prisma.XOR<Prisma.CartItemCreateInput, Prisma.CartItemUncheckedCreateInput>;
    /**
     * In case the CartItem was found with the provided `where` argument, update it with this data.
     */
    update: Prisma.XOR<Prisma.CartItemUpdateInput, Prisma.CartItemUncheckedUpdateInput>;
};
/**
 * CartItem delete
 */
export type CartItemDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
    /**
     * Filter which CartItem to delete.
     */
    where: Prisma.CartItemWhereUniqueInput;
};
/**
 * CartItem deleteMany
 */
export type CartItemDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which CartItems to delete
     */
    where?: Prisma.CartItemWhereInput;
    /**
     * Limit how many CartItems to delete.
     */
    limit?: number;
};
/**
 * CartItem without action
 */
export type CartItemDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the CartItem
     */
    select?: Prisma.CartItemSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the CartItem
     */
    omit?: Prisma.CartItemOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.CartItemInclude<ExtArgs> | null;
};
//# sourceMappingURL=CartItem.d.ts.map