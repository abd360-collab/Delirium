import type * as runtime from "@prisma/client/runtime/client";
import type * as $Enums from "../enums.js";
import type * as Prisma from "../internal/prismaNamespace.js";
/**
 * Model OutboxEvent
 *
 */
export type OutboxEventModel = runtime.Types.Result.DefaultSelection<Prisma.$OutboxEventPayload>;
export type AggregateOutboxEvent = {
    _count: OutboxEventCountAggregateOutputType | null;
    _avg: OutboxEventAvgAggregateOutputType | null;
    _sum: OutboxEventSumAggregateOutputType | null;
    _min: OutboxEventMinAggregateOutputType | null;
    _max: OutboxEventMaxAggregateOutputType | null;
};
export type OutboxEventAvgAggregateOutputType = {
    attempts: number | null;
};
export type OutboxEventSumAggregateOutputType = {
    attempts: number | null;
};
export type OutboxEventMinAggregateOutputType = {
    id: string | null;
    eventType: string | null;
    aggregateType: string | null;
    aggregateId: string | null;
    status: $Enums.OutboxEventStatus | null;
    attempts: number | null;
    availableAt: Date | null;
    processedAt: Date | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type OutboxEventMaxAggregateOutputType = {
    id: string | null;
    eventType: string | null;
    aggregateType: string | null;
    aggregateId: string | null;
    status: $Enums.OutboxEventStatus | null;
    attempts: number | null;
    availableAt: Date | null;
    processedAt: Date | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type OutboxEventCountAggregateOutputType = {
    id: number;
    eventType: number;
    aggregateType: number;
    aggregateId: number;
    payload: number;
    status: number;
    attempts: number;
    availableAt: number;
    processedAt: number;
    createdAt: number;
    updatedAt: number;
    _all: number;
};
export type OutboxEventAvgAggregateInputType = {
    attempts?: true;
};
export type OutboxEventSumAggregateInputType = {
    attempts?: true;
};
export type OutboxEventMinAggregateInputType = {
    id?: true;
    eventType?: true;
    aggregateType?: true;
    aggregateId?: true;
    status?: true;
    attempts?: true;
    availableAt?: true;
    processedAt?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type OutboxEventMaxAggregateInputType = {
    id?: true;
    eventType?: true;
    aggregateType?: true;
    aggregateId?: true;
    status?: true;
    attempts?: true;
    availableAt?: true;
    processedAt?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type OutboxEventCountAggregateInputType = {
    id?: true;
    eventType?: true;
    aggregateType?: true;
    aggregateId?: true;
    payload?: true;
    status?: true;
    attempts?: true;
    availableAt?: true;
    processedAt?: true;
    createdAt?: true;
    updatedAt?: true;
    _all?: true;
};
export type OutboxEventAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which OutboxEvent to aggregate.
     */
    where?: Prisma.OutboxEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of OutboxEvents to fetch.
     */
    orderBy?: Prisma.OutboxEventOrderByWithRelationInput | Prisma.OutboxEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the start position
     */
    cursor?: Prisma.OutboxEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` OutboxEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` OutboxEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Count returned OutboxEvents
    **/
    _count?: true | OutboxEventCountAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to average
    **/
    _avg?: OutboxEventAvgAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to sum
    **/
    _sum?: OutboxEventSumAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the minimum value
    **/
    _min?: OutboxEventMinAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the maximum value
    **/
    _max?: OutboxEventMaxAggregateInputType;
};
export type GetOutboxEventAggregateType<T extends OutboxEventAggregateArgs> = {
    [P in keyof T & keyof AggregateOutboxEvent]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateOutboxEvent[P]> : Prisma.GetScalarType<T[P], AggregateOutboxEvent[P]>;
};
export type OutboxEventGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.OutboxEventWhereInput;
    orderBy?: Prisma.OutboxEventOrderByWithAggregationInput | Prisma.OutboxEventOrderByWithAggregationInput[];
    by: Prisma.OutboxEventScalarFieldEnum[] | Prisma.OutboxEventScalarFieldEnum;
    having?: Prisma.OutboxEventScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: OutboxEventCountAggregateInputType | true;
    _avg?: OutboxEventAvgAggregateInputType;
    _sum?: OutboxEventSumAggregateInputType;
    _min?: OutboxEventMinAggregateInputType;
    _max?: OutboxEventMaxAggregateInputType;
};
export type OutboxEventGroupByOutputType = {
    id: string;
    eventType: string;
    aggregateType: string;
    aggregateId: string;
    payload: runtime.JsonValue;
    status: $Enums.OutboxEventStatus;
    attempts: number;
    availableAt: Date;
    processedAt: Date | null;
    createdAt: Date;
    updatedAt: Date;
    _count: OutboxEventCountAggregateOutputType | null;
    _avg: OutboxEventAvgAggregateOutputType | null;
    _sum: OutboxEventSumAggregateOutputType | null;
    _min: OutboxEventMinAggregateOutputType | null;
    _max: OutboxEventMaxAggregateOutputType | null;
};
export type GetOutboxEventGroupByPayload<T extends OutboxEventGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<OutboxEventGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof OutboxEventGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], OutboxEventGroupByOutputType[P]> : Prisma.GetScalarType<T[P], OutboxEventGroupByOutputType[P]>;
}>>;
export type OutboxEventWhereInput = {
    AND?: Prisma.OutboxEventWhereInput | Prisma.OutboxEventWhereInput[];
    OR?: Prisma.OutboxEventWhereInput[];
    NOT?: Prisma.OutboxEventWhereInput | Prisma.OutboxEventWhereInput[];
    id?: Prisma.StringFilter<"OutboxEvent"> | string;
    eventType?: Prisma.StringFilter<"OutboxEvent"> | string;
    aggregateType?: Prisma.StringFilter<"OutboxEvent"> | string;
    aggregateId?: Prisma.StringFilter<"OutboxEvent"> | string;
    payload?: Prisma.JsonFilter<"OutboxEvent">;
    status?: Prisma.EnumOutboxEventStatusFilter<"OutboxEvent"> | $Enums.OutboxEventStatus;
    attempts?: Prisma.IntFilter<"OutboxEvent"> | number;
    availableAt?: Prisma.DateTimeFilter<"OutboxEvent"> | Date | string;
    processedAt?: Prisma.DateTimeNullableFilter<"OutboxEvent"> | Date | string | null;
    createdAt?: Prisma.DateTimeFilter<"OutboxEvent"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"OutboxEvent"> | Date | string;
};
export type OutboxEventOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    aggregateType?: Prisma.SortOrder;
    aggregateId?: Prisma.SortOrder;
    payload?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    attempts?: Prisma.SortOrder;
    availableAt?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type OutboxEventWhereUniqueInput = Prisma.AtLeast<{
    id?: string;
    AND?: Prisma.OutboxEventWhereInput | Prisma.OutboxEventWhereInput[];
    OR?: Prisma.OutboxEventWhereInput[];
    NOT?: Prisma.OutboxEventWhereInput | Prisma.OutboxEventWhereInput[];
    eventType?: Prisma.StringFilter<"OutboxEvent"> | string;
    aggregateType?: Prisma.StringFilter<"OutboxEvent"> | string;
    aggregateId?: Prisma.StringFilter<"OutboxEvent"> | string;
    payload?: Prisma.JsonFilter<"OutboxEvent">;
    status?: Prisma.EnumOutboxEventStatusFilter<"OutboxEvent"> | $Enums.OutboxEventStatus;
    attempts?: Prisma.IntFilter<"OutboxEvent"> | number;
    availableAt?: Prisma.DateTimeFilter<"OutboxEvent"> | Date | string;
    processedAt?: Prisma.DateTimeNullableFilter<"OutboxEvent"> | Date | string | null;
    createdAt?: Prisma.DateTimeFilter<"OutboxEvent"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"OutboxEvent"> | Date | string;
}, "id">;
export type OutboxEventOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    aggregateType?: Prisma.SortOrder;
    aggregateId?: Prisma.SortOrder;
    payload?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    attempts?: Prisma.SortOrder;
    availableAt?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    _count?: Prisma.OutboxEventCountOrderByAggregateInput;
    _avg?: Prisma.OutboxEventAvgOrderByAggregateInput;
    _max?: Prisma.OutboxEventMaxOrderByAggregateInput;
    _min?: Prisma.OutboxEventMinOrderByAggregateInput;
    _sum?: Prisma.OutboxEventSumOrderByAggregateInput;
};
export type OutboxEventScalarWhereWithAggregatesInput = {
    AND?: Prisma.OutboxEventScalarWhereWithAggregatesInput | Prisma.OutboxEventScalarWhereWithAggregatesInput[];
    OR?: Prisma.OutboxEventScalarWhereWithAggregatesInput[];
    NOT?: Prisma.OutboxEventScalarWhereWithAggregatesInput | Prisma.OutboxEventScalarWhereWithAggregatesInput[];
    id?: Prisma.StringWithAggregatesFilter<"OutboxEvent"> | string;
    eventType?: Prisma.StringWithAggregatesFilter<"OutboxEvent"> | string;
    aggregateType?: Prisma.StringWithAggregatesFilter<"OutboxEvent"> | string;
    aggregateId?: Prisma.StringWithAggregatesFilter<"OutboxEvent"> | string;
    payload?: Prisma.JsonWithAggregatesFilter<"OutboxEvent">;
    status?: Prisma.EnumOutboxEventStatusWithAggregatesFilter<"OutboxEvent"> | $Enums.OutboxEventStatus;
    attempts?: Prisma.IntWithAggregatesFilter<"OutboxEvent"> | number;
    availableAt?: Prisma.DateTimeWithAggregatesFilter<"OutboxEvent"> | Date | string;
    processedAt?: Prisma.DateTimeNullableWithAggregatesFilter<"OutboxEvent"> | Date | string | null;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"OutboxEvent"> | Date | string;
    updatedAt?: Prisma.DateTimeWithAggregatesFilter<"OutboxEvent"> | Date | string;
};
export type OutboxEventCreateInput = {
    id?: string;
    eventType: string;
    aggregateType: string;
    aggregateId: string;
    payload: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    status?: $Enums.OutboxEventStatus;
    attempts?: number;
    availableAt?: Date | string;
    processedAt?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type OutboxEventUncheckedCreateInput = {
    id?: string;
    eventType: string;
    aggregateType: string;
    aggregateId: string;
    payload: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    status?: $Enums.OutboxEventStatus;
    attempts?: number;
    availableAt?: Date | string;
    processedAt?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type OutboxEventUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateId?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    status?: Prisma.EnumOutboxEventStatusFieldUpdateOperationsInput | $Enums.OutboxEventStatus;
    attempts?: Prisma.IntFieldUpdateOperationsInput | number;
    availableAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type OutboxEventUncheckedUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateId?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    status?: Prisma.EnumOutboxEventStatusFieldUpdateOperationsInput | $Enums.OutboxEventStatus;
    attempts?: Prisma.IntFieldUpdateOperationsInput | number;
    availableAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type OutboxEventCreateManyInput = {
    id?: string;
    eventType: string;
    aggregateType: string;
    aggregateId: string;
    payload: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    status?: $Enums.OutboxEventStatus;
    attempts?: number;
    availableAt?: Date | string;
    processedAt?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type OutboxEventUpdateManyMutationInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateId?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    status?: Prisma.EnumOutboxEventStatusFieldUpdateOperationsInput | $Enums.OutboxEventStatus;
    attempts?: Prisma.IntFieldUpdateOperationsInput | number;
    availableAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type OutboxEventUncheckedUpdateManyInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateType?: Prisma.StringFieldUpdateOperationsInput | string;
    aggregateId?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    status?: Prisma.EnumOutboxEventStatusFieldUpdateOperationsInput | $Enums.OutboxEventStatus;
    attempts?: Prisma.IntFieldUpdateOperationsInput | number;
    availableAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type OutboxEventCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    aggregateType?: Prisma.SortOrder;
    aggregateId?: Prisma.SortOrder;
    payload?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    attempts?: Prisma.SortOrder;
    availableAt?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type OutboxEventAvgOrderByAggregateInput = {
    attempts?: Prisma.SortOrder;
};
export type OutboxEventMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    aggregateType?: Prisma.SortOrder;
    aggregateId?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    attempts?: Prisma.SortOrder;
    availableAt?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type OutboxEventMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    aggregateType?: Prisma.SortOrder;
    aggregateId?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    attempts?: Prisma.SortOrder;
    availableAt?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type OutboxEventSumOrderByAggregateInput = {
    attempts?: Prisma.SortOrder;
};
export type EnumOutboxEventStatusFieldUpdateOperationsInput = {
    set?: $Enums.OutboxEventStatus;
};
export type OutboxEventSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    eventType?: boolean;
    aggregateType?: boolean;
    aggregateId?: boolean;
    payload?: boolean;
    status?: boolean;
    attempts?: boolean;
    availableAt?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
}, ExtArgs["result"]["outboxEvent"]>;
export type OutboxEventSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    eventType?: boolean;
    aggregateType?: boolean;
    aggregateId?: boolean;
    payload?: boolean;
    status?: boolean;
    attempts?: boolean;
    availableAt?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
}, ExtArgs["result"]["outboxEvent"]>;
export type OutboxEventSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    eventType?: boolean;
    aggregateType?: boolean;
    aggregateId?: boolean;
    payload?: boolean;
    status?: boolean;
    attempts?: boolean;
    availableAt?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
}, ExtArgs["result"]["outboxEvent"]>;
export type OutboxEventSelectScalar = {
    id?: boolean;
    eventType?: boolean;
    aggregateType?: boolean;
    aggregateId?: boolean;
    payload?: boolean;
    status?: boolean;
    attempts?: boolean;
    availableAt?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
};
export type OutboxEventOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "eventType" | "aggregateType" | "aggregateId" | "payload" | "status" | "attempts" | "availableAt" | "processedAt" | "createdAt" | "updatedAt", ExtArgs["result"]["outboxEvent"]>;
export type $OutboxEventPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "OutboxEvent";
    objects: {};
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: string;
        eventType: string;
        aggregateType: string;
        aggregateId: string;
        payload: runtime.JsonValue;
        status: $Enums.OutboxEventStatus;
        attempts: number;
        availableAt: Date;
        processedAt: Date | null;
        createdAt: Date;
        updatedAt: Date;
    }, ExtArgs["result"]["outboxEvent"]>;
    composites: {};
};
export type OutboxEventGetPayload<S extends boolean | null | undefined | OutboxEventDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload, S>;
export type OutboxEventCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<OutboxEventFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: OutboxEventCountAggregateInputType | true;
};
export interface OutboxEventDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['OutboxEvent'];
        meta: {
            name: 'OutboxEvent';
        };
    };
    /**
     * Find zero or one OutboxEvent that matches the filter.
     * @param {OutboxEventFindUniqueArgs} args - Arguments to find a OutboxEvent
     * @example
     * // Get one OutboxEvent
     * const outboxEvent = await prisma.outboxEvent.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends OutboxEventFindUniqueArgs>(args: Prisma.SelectSubset<T, OutboxEventFindUniqueArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find one OutboxEvent that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {OutboxEventFindUniqueOrThrowArgs} args - Arguments to find a OutboxEvent
     * @example
     * // Get one OutboxEvent
     * const outboxEvent = await prisma.outboxEvent.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends OutboxEventFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, OutboxEventFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first OutboxEvent that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OutboxEventFindFirstArgs} args - Arguments to find a OutboxEvent
     * @example
     * // Get one OutboxEvent
     * const outboxEvent = await prisma.outboxEvent.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends OutboxEventFindFirstArgs>(args?: Prisma.SelectSubset<T, OutboxEventFindFirstArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first OutboxEvent that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OutboxEventFindFirstOrThrowArgs} args - Arguments to find a OutboxEvent
     * @example
     * // Get one OutboxEvent
     * const outboxEvent = await prisma.outboxEvent.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends OutboxEventFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, OutboxEventFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find zero or more OutboxEvents that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OutboxEventFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all OutboxEvents
     * const outboxEvents = await prisma.outboxEvent.findMany()
     *
     * // Get first 10 OutboxEvents
     * const outboxEvents = await prisma.outboxEvent.findMany({ take: 10 })
     *
     * // Only select the `id`
     * const outboxEventWithIdOnly = await prisma.outboxEvent.findMany({ select: { id: true } })
     *
     */
    findMany<T extends OutboxEventFindManyArgs>(args?: Prisma.SelectSubset<T, OutboxEventFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    /**
     * Create a OutboxEvent.
     * @param {OutboxEventCreateArgs} args - Arguments to create a OutboxEvent.
     * @example
     * // Create one OutboxEvent
     * const OutboxEvent = await prisma.outboxEvent.create({
     *   data: {
     *     // ... data to create a OutboxEvent
     *   }
     * })
     *
     */
    create<T extends OutboxEventCreateArgs>(args: Prisma.SelectSubset<T, OutboxEventCreateArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Create many OutboxEvents.
     * @param {OutboxEventCreateManyArgs} args - Arguments to create many OutboxEvents.
     * @example
     * // Create many OutboxEvents
     * const outboxEvent = await prisma.outboxEvent.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     */
    createMany<T extends OutboxEventCreateManyArgs>(args?: Prisma.SelectSubset<T, OutboxEventCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Create many OutboxEvents and returns the data saved in the database.
     * @param {OutboxEventCreateManyAndReturnArgs} args - Arguments to create many OutboxEvents.
     * @example
     * // Create many OutboxEvents
     * const outboxEvent = await prisma.outboxEvent.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Create many OutboxEvents and only return the `id`
     * const outboxEventWithIdOnly = await prisma.outboxEvent.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    createManyAndReturn<T extends OutboxEventCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, OutboxEventCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    /**
     * Delete a OutboxEvent.
     * @param {OutboxEventDeleteArgs} args - Arguments to delete one OutboxEvent.
     * @example
     * // Delete one OutboxEvent
     * const OutboxEvent = await prisma.outboxEvent.delete({
     *   where: {
     *     // ... filter to delete one OutboxEvent
     *   }
     * })
     *
     */
    delete<T extends OutboxEventDeleteArgs>(args: Prisma.SelectSubset<T, OutboxEventDeleteArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Update one OutboxEvent.
     * @param {OutboxEventUpdateArgs} args - Arguments to update one OutboxEvent.
     * @example
     * // Update one OutboxEvent
     * const outboxEvent = await prisma.outboxEvent.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    update<T extends OutboxEventUpdateArgs>(args: Prisma.SelectSubset<T, OutboxEventUpdateArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Delete zero or more OutboxEvents.
     * @param {OutboxEventDeleteManyArgs} args - Arguments to filter OutboxEvents to delete.
     * @example
     * // Delete a few OutboxEvents
     * const { count } = await prisma.outboxEvent.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     *
     */
    deleteMany<T extends OutboxEventDeleteManyArgs>(args?: Prisma.SelectSubset<T, OutboxEventDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more OutboxEvents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OutboxEventUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many OutboxEvents
     * const outboxEvent = await prisma.outboxEvent.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    updateMany<T extends OutboxEventUpdateManyArgs>(args: Prisma.SelectSubset<T, OutboxEventUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more OutboxEvents and returns the data updated in the database.
     * @param {OutboxEventUpdateManyAndReturnArgs} args - Arguments to update many OutboxEvents.
     * @example
     * // Update many OutboxEvents
     * const outboxEvent = await prisma.outboxEvent.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Update zero or more OutboxEvents and only return the `id`
     * const outboxEventWithIdOnly = await prisma.outboxEvent.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    updateManyAndReturn<T extends OutboxEventUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, OutboxEventUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    /**
     * Create or update one OutboxEvent.
     * @param {OutboxEventUpsertArgs} args - Arguments to update or create a OutboxEvent.
     * @example
     * // Update or create a OutboxEvent
     * const outboxEvent = await prisma.outboxEvent.upsert({
     *   create: {
     *     // ... data to create a OutboxEvent
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the OutboxEvent we want to update
     *   }
     * })
     */
    upsert<T extends OutboxEventUpsertArgs>(args: Prisma.SelectSubset<T, OutboxEventUpsertArgs<ExtArgs>>): Prisma.Prisma__OutboxEventClient<runtime.Types.Result.GetResult<Prisma.$OutboxEventPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Count the number of OutboxEvents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OutboxEventCountArgs} args - Arguments to filter OutboxEvents to count.
     * @example
     * // Count the number of OutboxEvents
     * const count = await prisma.outboxEvent.count({
     *   where: {
     *     // ... the filter for the OutboxEvents we want to count
     *   }
     * })
    **/
    count<T extends OutboxEventCountArgs>(args?: Prisma.Subset<T, OutboxEventCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], OutboxEventCountAggregateOutputType> : number>;
    /**
     * Allows you to perform aggregations operations on a OutboxEvent.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OutboxEventAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends OutboxEventAggregateArgs>(args: Prisma.Subset<T, OutboxEventAggregateArgs>): Prisma.PrismaPromise<GetOutboxEventAggregateType<T>>;
    /**
     * Group by OutboxEvent.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {OutboxEventGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     *
    **/
    groupBy<T extends OutboxEventGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: OutboxEventGroupByArgs['orderBy'];
    } : {
        orderBy?: OutboxEventGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, OutboxEventGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetOutboxEventGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    /**
     * Fields of the OutboxEvent model
     */
    readonly fields: OutboxEventFieldRefs;
}
/**
 * The delegate class that acts as a "Promise-like" for OutboxEvent.
 * Why is this prefixed with `Prisma__`?
 * Because we want to prevent naming conflicts as mentioned in
 * https://github.com/prisma/prisma-client-js/issues/707
 */
export interface Prisma__OutboxEventClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
/**
 * Fields of the OutboxEvent model
 */
export interface OutboxEventFieldRefs {
    readonly id: Prisma.FieldRef<"OutboxEvent", 'String'>;
    readonly eventType: Prisma.FieldRef<"OutboxEvent", 'String'>;
    readonly aggregateType: Prisma.FieldRef<"OutboxEvent", 'String'>;
    readonly aggregateId: Prisma.FieldRef<"OutboxEvent", 'String'>;
    readonly payload: Prisma.FieldRef<"OutboxEvent", 'Json'>;
    readonly status: Prisma.FieldRef<"OutboxEvent", 'OutboxEventStatus'>;
    readonly attempts: Prisma.FieldRef<"OutboxEvent", 'Int'>;
    readonly availableAt: Prisma.FieldRef<"OutboxEvent", 'DateTime'>;
    readonly processedAt: Prisma.FieldRef<"OutboxEvent", 'DateTime'>;
    readonly createdAt: Prisma.FieldRef<"OutboxEvent", 'DateTime'>;
    readonly updatedAt: Prisma.FieldRef<"OutboxEvent", 'DateTime'>;
}
/**
 * OutboxEvent findUnique
 */
export type OutboxEventFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * Filter, which OutboxEvent to fetch.
     */
    where: Prisma.OutboxEventWhereUniqueInput;
};
/**
 * OutboxEvent findUniqueOrThrow
 */
export type OutboxEventFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * Filter, which OutboxEvent to fetch.
     */
    where: Prisma.OutboxEventWhereUniqueInput;
};
/**
 * OutboxEvent findFirst
 */
export type OutboxEventFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * Filter, which OutboxEvent to fetch.
     */
    where?: Prisma.OutboxEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of OutboxEvents to fetch.
     */
    orderBy?: Prisma.OutboxEventOrderByWithRelationInput | Prisma.OutboxEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for OutboxEvents.
     */
    cursor?: Prisma.OutboxEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` OutboxEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` OutboxEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of OutboxEvents.
     */
    distinct?: Prisma.OutboxEventScalarFieldEnum | Prisma.OutboxEventScalarFieldEnum[];
};
/**
 * OutboxEvent findFirstOrThrow
 */
export type OutboxEventFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * Filter, which OutboxEvent to fetch.
     */
    where?: Prisma.OutboxEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of OutboxEvents to fetch.
     */
    orderBy?: Prisma.OutboxEventOrderByWithRelationInput | Prisma.OutboxEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for OutboxEvents.
     */
    cursor?: Prisma.OutboxEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` OutboxEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` OutboxEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of OutboxEvents.
     */
    distinct?: Prisma.OutboxEventScalarFieldEnum | Prisma.OutboxEventScalarFieldEnum[];
};
/**
 * OutboxEvent findMany
 */
export type OutboxEventFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * Filter, which OutboxEvents to fetch.
     */
    where?: Prisma.OutboxEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of OutboxEvents to fetch.
     */
    orderBy?: Prisma.OutboxEventOrderByWithRelationInput | Prisma.OutboxEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for listing OutboxEvents.
     */
    cursor?: Prisma.OutboxEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` OutboxEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` OutboxEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of OutboxEvents.
     */
    distinct?: Prisma.OutboxEventScalarFieldEnum | Prisma.OutboxEventScalarFieldEnum[];
};
/**
 * OutboxEvent create
 */
export type OutboxEventCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * The data needed to create a OutboxEvent.
     */
    data: Prisma.XOR<Prisma.OutboxEventCreateInput, Prisma.OutboxEventUncheckedCreateInput>;
};
/**
 * OutboxEvent createMany
 */
export type OutboxEventCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to create many OutboxEvents.
     */
    data: Prisma.OutboxEventCreateManyInput | Prisma.OutboxEventCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * OutboxEvent createManyAndReturn
 */
export type OutboxEventCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelectCreateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * The data used to create many OutboxEvents.
     */
    data: Prisma.OutboxEventCreateManyInput | Prisma.OutboxEventCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * OutboxEvent update
 */
export type OutboxEventUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * The data needed to update a OutboxEvent.
     */
    data: Prisma.XOR<Prisma.OutboxEventUpdateInput, Prisma.OutboxEventUncheckedUpdateInput>;
    /**
     * Choose, which OutboxEvent to update.
     */
    where: Prisma.OutboxEventWhereUniqueInput;
};
/**
 * OutboxEvent updateMany
 */
export type OutboxEventUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to update OutboxEvents.
     */
    data: Prisma.XOR<Prisma.OutboxEventUpdateManyMutationInput, Prisma.OutboxEventUncheckedUpdateManyInput>;
    /**
     * Filter which OutboxEvents to update
     */
    where?: Prisma.OutboxEventWhereInput;
    /**
     * Limit how many OutboxEvents to update.
     */
    limit?: number;
};
/**
 * OutboxEvent updateManyAndReturn
 */
export type OutboxEventUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelectUpdateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * The data used to update OutboxEvents.
     */
    data: Prisma.XOR<Prisma.OutboxEventUpdateManyMutationInput, Prisma.OutboxEventUncheckedUpdateManyInput>;
    /**
     * Filter which OutboxEvents to update
     */
    where?: Prisma.OutboxEventWhereInput;
    /**
     * Limit how many OutboxEvents to update.
     */
    limit?: number;
};
/**
 * OutboxEvent upsert
 */
export type OutboxEventUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * The filter to search for the OutboxEvent to update in case it exists.
     */
    where: Prisma.OutboxEventWhereUniqueInput;
    /**
     * In case the OutboxEvent found by the `where` argument doesn't exist, create a new OutboxEvent with this data.
     */
    create: Prisma.XOR<Prisma.OutboxEventCreateInput, Prisma.OutboxEventUncheckedCreateInput>;
    /**
     * In case the OutboxEvent was found with the provided `where` argument, update it with this data.
     */
    update: Prisma.XOR<Prisma.OutboxEventUpdateInput, Prisma.OutboxEventUncheckedUpdateInput>;
};
/**
 * OutboxEvent delete
 */
export type OutboxEventDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
    /**
     * Filter which OutboxEvent to delete.
     */
    where: Prisma.OutboxEventWhereUniqueInput;
};
/**
 * OutboxEvent deleteMany
 */
export type OutboxEventDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which OutboxEvents to delete
     */
    where?: Prisma.OutboxEventWhereInput;
    /**
     * Limit how many OutboxEvents to delete.
     */
    limit?: number;
};
/**
 * OutboxEvent without action
 */
export type OutboxEventDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the OutboxEvent
     */
    select?: Prisma.OutboxEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the OutboxEvent
     */
    omit?: Prisma.OutboxEventOmit<ExtArgs> | null;
};
//# sourceMappingURL=OutboxEvent.d.ts.map