import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
/**
 * Model WebhookEvent
 *
 */
export type WebhookEventModel = runtime.Types.Result.DefaultSelection<Prisma.$WebhookEventPayload>;
export type AggregateWebhookEvent = {
    _count: WebhookEventCountAggregateOutputType | null;
    _min: WebhookEventMinAggregateOutputType | null;
    _max: WebhookEventMaxAggregateOutputType | null;
};
export type WebhookEventMinAggregateOutputType = {
    id: string | null;
    provider: string | null;
    eventId: string | null;
    eventType: string | null;
    processedAt: Date | null;
    createdAt: Date | null;
};
export type WebhookEventMaxAggregateOutputType = {
    id: string | null;
    provider: string | null;
    eventId: string | null;
    eventType: string | null;
    processedAt: Date | null;
    createdAt: Date | null;
};
export type WebhookEventCountAggregateOutputType = {
    id: number;
    provider: number;
    eventId: number;
    eventType: number;
    payload: number;
    processedAt: number;
    createdAt: number;
    _all: number;
};
export type WebhookEventMinAggregateInputType = {
    id?: true;
    provider?: true;
    eventId?: true;
    eventType?: true;
    processedAt?: true;
    createdAt?: true;
};
export type WebhookEventMaxAggregateInputType = {
    id?: true;
    provider?: true;
    eventId?: true;
    eventType?: true;
    processedAt?: true;
    createdAt?: true;
};
export type WebhookEventCountAggregateInputType = {
    id?: true;
    provider?: true;
    eventId?: true;
    eventType?: true;
    payload?: true;
    processedAt?: true;
    createdAt?: true;
    _all?: true;
};
export type WebhookEventAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which WebhookEvent to aggregate.
     */
    where?: Prisma.WebhookEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of WebhookEvents to fetch.
     */
    orderBy?: Prisma.WebhookEventOrderByWithRelationInput | Prisma.WebhookEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the start position
     */
    cursor?: Prisma.WebhookEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` WebhookEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` WebhookEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Count returned WebhookEvents
    **/
    _count?: true | WebhookEventCountAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the minimum value
    **/
    _min?: WebhookEventMinAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the maximum value
    **/
    _max?: WebhookEventMaxAggregateInputType;
};
export type GetWebhookEventAggregateType<T extends WebhookEventAggregateArgs> = {
    [P in keyof T & keyof AggregateWebhookEvent]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateWebhookEvent[P]> : Prisma.GetScalarType<T[P], AggregateWebhookEvent[P]>;
};
export type WebhookEventGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.WebhookEventWhereInput;
    orderBy?: Prisma.WebhookEventOrderByWithAggregationInput | Prisma.WebhookEventOrderByWithAggregationInput[];
    by: Prisma.WebhookEventScalarFieldEnum[] | Prisma.WebhookEventScalarFieldEnum;
    having?: Prisma.WebhookEventScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: WebhookEventCountAggregateInputType | true;
    _min?: WebhookEventMinAggregateInputType;
    _max?: WebhookEventMaxAggregateInputType;
};
export type WebhookEventGroupByOutputType = {
    id: string;
    provider: string;
    eventId: string;
    eventType: string;
    payload: runtime.JsonValue;
    processedAt: Date | null;
    createdAt: Date;
    _count: WebhookEventCountAggregateOutputType | null;
    _min: WebhookEventMinAggregateOutputType | null;
    _max: WebhookEventMaxAggregateOutputType | null;
};
export type GetWebhookEventGroupByPayload<T extends WebhookEventGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<WebhookEventGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof WebhookEventGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], WebhookEventGroupByOutputType[P]> : Prisma.GetScalarType<T[P], WebhookEventGroupByOutputType[P]>;
}>>;
export type WebhookEventWhereInput = {
    AND?: Prisma.WebhookEventWhereInput | Prisma.WebhookEventWhereInput[];
    OR?: Prisma.WebhookEventWhereInput[];
    NOT?: Prisma.WebhookEventWhereInput | Prisma.WebhookEventWhereInput[];
    id?: Prisma.StringFilter<"WebhookEvent"> | string;
    provider?: Prisma.StringFilter<"WebhookEvent"> | string;
    eventId?: Prisma.StringFilter<"WebhookEvent"> | string;
    eventType?: Prisma.StringFilter<"WebhookEvent"> | string;
    payload?: Prisma.JsonFilter<"WebhookEvent">;
    processedAt?: Prisma.DateTimeNullableFilter<"WebhookEvent"> | Date | string | null;
    createdAt?: Prisma.DateTimeFilter<"WebhookEvent"> | Date | string;
};
export type WebhookEventOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    provider?: Prisma.SortOrder;
    eventId?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    payload?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
};
export type WebhookEventWhereUniqueInput = Prisma.AtLeast<{
    id?: string;
    provider_eventId?: Prisma.WebhookEventProviderEventIdCompoundUniqueInput;
    AND?: Prisma.WebhookEventWhereInput | Prisma.WebhookEventWhereInput[];
    OR?: Prisma.WebhookEventWhereInput[];
    NOT?: Prisma.WebhookEventWhereInput | Prisma.WebhookEventWhereInput[];
    provider?: Prisma.StringFilter<"WebhookEvent"> | string;
    eventId?: Prisma.StringFilter<"WebhookEvent"> | string;
    eventType?: Prisma.StringFilter<"WebhookEvent"> | string;
    payload?: Prisma.JsonFilter<"WebhookEvent">;
    processedAt?: Prisma.DateTimeNullableFilter<"WebhookEvent"> | Date | string | null;
    createdAt?: Prisma.DateTimeFilter<"WebhookEvent"> | Date | string;
}, "id" | "provider_eventId">;
export type WebhookEventOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    provider?: Prisma.SortOrder;
    eventId?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    payload?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    _count?: Prisma.WebhookEventCountOrderByAggregateInput;
    _max?: Prisma.WebhookEventMaxOrderByAggregateInput;
    _min?: Prisma.WebhookEventMinOrderByAggregateInput;
};
export type WebhookEventScalarWhereWithAggregatesInput = {
    AND?: Prisma.WebhookEventScalarWhereWithAggregatesInput | Prisma.WebhookEventScalarWhereWithAggregatesInput[];
    OR?: Prisma.WebhookEventScalarWhereWithAggregatesInput[];
    NOT?: Prisma.WebhookEventScalarWhereWithAggregatesInput | Prisma.WebhookEventScalarWhereWithAggregatesInput[];
    id?: Prisma.StringWithAggregatesFilter<"WebhookEvent"> | string;
    provider?: Prisma.StringWithAggregatesFilter<"WebhookEvent"> | string;
    eventId?: Prisma.StringWithAggregatesFilter<"WebhookEvent"> | string;
    eventType?: Prisma.StringWithAggregatesFilter<"WebhookEvent"> | string;
    payload?: Prisma.JsonWithAggregatesFilter<"WebhookEvent">;
    processedAt?: Prisma.DateTimeNullableWithAggregatesFilter<"WebhookEvent"> | Date | string | null;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"WebhookEvent"> | Date | string;
};
export type WebhookEventCreateInput = {
    id?: string;
    provider: string;
    eventId: string;
    eventType: string;
    payload: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    processedAt?: Date | string | null;
    createdAt?: Date | string;
};
export type WebhookEventUncheckedCreateInput = {
    id?: string;
    provider: string;
    eventId: string;
    eventType: string;
    payload: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    processedAt?: Date | string | null;
    createdAt?: Date | string;
};
export type WebhookEventUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    provider?: Prisma.StringFieldUpdateOperationsInput | string;
    eventId?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type WebhookEventUncheckedUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    provider?: Prisma.StringFieldUpdateOperationsInput | string;
    eventId?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type WebhookEventCreateManyInput = {
    id?: string;
    provider: string;
    eventId: string;
    eventType: string;
    payload: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    processedAt?: Date | string | null;
    createdAt?: Date | string;
};
export type WebhookEventUpdateManyMutationInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    provider?: Prisma.StringFieldUpdateOperationsInput | string;
    eventId?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type WebhookEventUncheckedUpdateManyInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    provider?: Prisma.StringFieldUpdateOperationsInput | string;
    eventId?: Prisma.StringFieldUpdateOperationsInput | string;
    eventType?: Prisma.StringFieldUpdateOperationsInput | string;
    payload?: Prisma.JsonNullValueInput | runtime.InputJsonValue;
    processedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type WebhookEventProviderEventIdCompoundUniqueInput = {
    provider: string;
    eventId: string;
};
export type WebhookEventCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    provider?: Prisma.SortOrder;
    eventId?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    payload?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
};
export type WebhookEventMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    provider?: Prisma.SortOrder;
    eventId?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
};
export type WebhookEventMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    provider?: Prisma.SortOrder;
    eventId?: Prisma.SortOrder;
    eventType?: Prisma.SortOrder;
    processedAt?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
};
export type WebhookEventSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    provider?: boolean;
    eventId?: boolean;
    eventType?: boolean;
    payload?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
}, ExtArgs["result"]["webhookEvent"]>;
export type WebhookEventSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    provider?: boolean;
    eventId?: boolean;
    eventType?: boolean;
    payload?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
}, ExtArgs["result"]["webhookEvent"]>;
export type WebhookEventSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    provider?: boolean;
    eventId?: boolean;
    eventType?: boolean;
    payload?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
}, ExtArgs["result"]["webhookEvent"]>;
export type WebhookEventSelectScalar = {
    id?: boolean;
    provider?: boolean;
    eventId?: boolean;
    eventType?: boolean;
    payload?: boolean;
    processedAt?: boolean;
    createdAt?: boolean;
};
export type WebhookEventOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "provider" | "eventId" | "eventType" | "payload" | "processedAt" | "createdAt", ExtArgs["result"]["webhookEvent"]>;
export type $WebhookEventPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "WebhookEvent";
    objects: {};
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: string;
        provider: string;
        eventId: string;
        eventType: string;
        payload: runtime.JsonValue;
        processedAt: Date | null;
        createdAt: Date;
    }, ExtArgs["result"]["webhookEvent"]>;
    composites: {};
};
export type WebhookEventGetPayload<S extends boolean | null | undefined | WebhookEventDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload, S>;
export type WebhookEventCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<WebhookEventFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: WebhookEventCountAggregateInputType | true;
};
export interface WebhookEventDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['WebhookEvent'];
        meta: {
            name: 'WebhookEvent';
        };
    };
    /**
     * Find zero or one WebhookEvent that matches the filter.
     * @param {WebhookEventFindUniqueArgs} args - Arguments to find a WebhookEvent
     * @example
     * // Get one WebhookEvent
     * const webhookEvent = await prisma.webhookEvent.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends WebhookEventFindUniqueArgs>(args: Prisma.SelectSubset<T, WebhookEventFindUniqueArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find one WebhookEvent that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {WebhookEventFindUniqueOrThrowArgs} args - Arguments to find a WebhookEvent
     * @example
     * // Get one WebhookEvent
     * const webhookEvent = await prisma.webhookEvent.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends WebhookEventFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, WebhookEventFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first WebhookEvent that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebhookEventFindFirstArgs} args - Arguments to find a WebhookEvent
     * @example
     * // Get one WebhookEvent
     * const webhookEvent = await prisma.webhookEvent.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends WebhookEventFindFirstArgs>(args?: Prisma.SelectSubset<T, WebhookEventFindFirstArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first WebhookEvent that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebhookEventFindFirstOrThrowArgs} args - Arguments to find a WebhookEvent
     * @example
     * // Get one WebhookEvent
     * const webhookEvent = await prisma.webhookEvent.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends WebhookEventFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, WebhookEventFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find zero or more WebhookEvents that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebhookEventFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all WebhookEvents
     * const webhookEvents = await prisma.webhookEvent.findMany()
     *
     * // Get first 10 WebhookEvents
     * const webhookEvents = await prisma.webhookEvent.findMany({ take: 10 })
     *
     * // Only select the `id`
     * const webhookEventWithIdOnly = await prisma.webhookEvent.findMany({ select: { id: true } })
     *
     */
    findMany<T extends WebhookEventFindManyArgs>(args?: Prisma.SelectSubset<T, WebhookEventFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    /**
     * Create a WebhookEvent.
     * @param {WebhookEventCreateArgs} args - Arguments to create a WebhookEvent.
     * @example
     * // Create one WebhookEvent
     * const WebhookEvent = await prisma.webhookEvent.create({
     *   data: {
     *     // ... data to create a WebhookEvent
     *   }
     * })
     *
     */
    create<T extends WebhookEventCreateArgs>(args: Prisma.SelectSubset<T, WebhookEventCreateArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Create many WebhookEvents.
     * @param {WebhookEventCreateManyArgs} args - Arguments to create many WebhookEvents.
     * @example
     * // Create many WebhookEvents
     * const webhookEvent = await prisma.webhookEvent.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     */
    createMany<T extends WebhookEventCreateManyArgs>(args?: Prisma.SelectSubset<T, WebhookEventCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Create many WebhookEvents and returns the data saved in the database.
     * @param {WebhookEventCreateManyAndReturnArgs} args - Arguments to create many WebhookEvents.
     * @example
     * // Create many WebhookEvents
     * const webhookEvent = await prisma.webhookEvent.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Create many WebhookEvents and only return the `id`
     * const webhookEventWithIdOnly = await prisma.webhookEvent.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    createManyAndReturn<T extends WebhookEventCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, WebhookEventCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    /**
     * Delete a WebhookEvent.
     * @param {WebhookEventDeleteArgs} args - Arguments to delete one WebhookEvent.
     * @example
     * // Delete one WebhookEvent
     * const WebhookEvent = await prisma.webhookEvent.delete({
     *   where: {
     *     // ... filter to delete one WebhookEvent
     *   }
     * })
     *
     */
    delete<T extends WebhookEventDeleteArgs>(args: Prisma.SelectSubset<T, WebhookEventDeleteArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Update one WebhookEvent.
     * @param {WebhookEventUpdateArgs} args - Arguments to update one WebhookEvent.
     * @example
     * // Update one WebhookEvent
     * const webhookEvent = await prisma.webhookEvent.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    update<T extends WebhookEventUpdateArgs>(args: Prisma.SelectSubset<T, WebhookEventUpdateArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Delete zero or more WebhookEvents.
     * @param {WebhookEventDeleteManyArgs} args - Arguments to filter WebhookEvents to delete.
     * @example
     * // Delete a few WebhookEvents
     * const { count } = await prisma.webhookEvent.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     *
     */
    deleteMany<T extends WebhookEventDeleteManyArgs>(args?: Prisma.SelectSubset<T, WebhookEventDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more WebhookEvents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebhookEventUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many WebhookEvents
     * const webhookEvent = await prisma.webhookEvent.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    updateMany<T extends WebhookEventUpdateManyArgs>(args: Prisma.SelectSubset<T, WebhookEventUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more WebhookEvents and returns the data updated in the database.
     * @param {WebhookEventUpdateManyAndReturnArgs} args - Arguments to update many WebhookEvents.
     * @example
     * // Update many WebhookEvents
     * const webhookEvent = await prisma.webhookEvent.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Update zero or more WebhookEvents and only return the `id`
     * const webhookEventWithIdOnly = await prisma.webhookEvent.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    updateManyAndReturn<T extends WebhookEventUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, WebhookEventUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    /**
     * Create or update one WebhookEvent.
     * @param {WebhookEventUpsertArgs} args - Arguments to update or create a WebhookEvent.
     * @example
     * // Update or create a WebhookEvent
     * const webhookEvent = await prisma.webhookEvent.upsert({
     *   create: {
     *     // ... data to create a WebhookEvent
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the WebhookEvent we want to update
     *   }
     * })
     */
    upsert<T extends WebhookEventUpsertArgs>(args: Prisma.SelectSubset<T, WebhookEventUpsertArgs<ExtArgs>>): Prisma.Prisma__WebhookEventClient<runtime.Types.Result.GetResult<Prisma.$WebhookEventPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Count the number of WebhookEvents.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebhookEventCountArgs} args - Arguments to filter WebhookEvents to count.
     * @example
     * // Count the number of WebhookEvents
     * const count = await prisma.webhookEvent.count({
     *   where: {
     *     // ... the filter for the WebhookEvents we want to count
     *   }
     * })
    **/
    count<T extends WebhookEventCountArgs>(args?: Prisma.Subset<T, WebhookEventCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], WebhookEventCountAggregateOutputType> : number>;
    /**
     * Allows you to perform aggregations operations on a WebhookEvent.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebhookEventAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends WebhookEventAggregateArgs>(args: Prisma.Subset<T, WebhookEventAggregateArgs>): Prisma.PrismaPromise<GetWebhookEventAggregateType<T>>;
    /**
     * Group by WebhookEvent.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {WebhookEventGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     *
    **/
    groupBy<T extends WebhookEventGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: WebhookEventGroupByArgs['orderBy'];
    } : {
        orderBy?: WebhookEventGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, WebhookEventGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetWebhookEventGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    /**
     * Fields of the WebhookEvent model
     */
    readonly fields: WebhookEventFieldRefs;
}
/**
 * The delegate class that acts as a "Promise-like" for WebhookEvent.
 * Why is this prefixed with `Prisma__`?
 * Because we want to prevent naming conflicts as mentioned in
 * https://github.com/prisma/prisma-client-js/issues/707
 */
export interface Prisma__WebhookEventClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
/**
 * Fields of the WebhookEvent model
 */
export interface WebhookEventFieldRefs {
    readonly id: Prisma.FieldRef<"WebhookEvent", 'String'>;
    readonly provider: Prisma.FieldRef<"WebhookEvent", 'String'>;
    readonly eventId: Prisma.FieldRef<"WebhookEvent", 'String'>;
    readonly eventType: Prisma.FieldRef<"WebhookEvent", 'String'>;
    readonly payload: Prisma.FieldRef<"WebhookEvent", 'Json'>;
    readonly processedAt: Prisma.FieldRef<"WebhookEvent", 'DateTime'>;
    readonly createdAt: Prisma.FieldRef<"WebhookEvent", 'DateTime'>;
}
/**
 * WebhookEvent findUnique
 */
export type WebhookEventFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * Filter, which WebhookEvent to fetch.
     */
    where: Prisma.WebhookEventWhereUniqueInput;
};
/**
 * WebhookEvent findUniqueOrThrow
 */
export type WebhookEventFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * Filter, which WebhookEvent to fetch.
     */
    where: Prisma.WebhookEventWhereUniqueInput;
};
/**
 * WebhookEvent findFirst
 */
export type WebhookEventFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * Filter, which WebhookEvent to fetch.
     */
    where?: Prisma.WebhookEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of WebhookEvents to fetch.
     */
    orderBy?: Prisma.WebhookEventOrderByWithRelationInput | Prisma.WebhookEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for WebhookEvents.
     */
    cursor?: Prisma.WebhookEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` WebhookEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` WebhookEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of WebhookEvents.
     */
    distinct?: Prisma.WebhookEventScalarFieldEnum | Prisma.WebhookEventScalarFieldEnum[];
};
/**
 * WebhookEvent findFirstOrThrow
 */
export type WebhookEventFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * Filter, which WebhookEvent to fetch.
     */
    where?: Prisma.WebhookEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of WebhookEvents to fetch.
     */
    orderBy?: Prisma.WebhookEventOrderByWithRelationInput | Prisma.WebhookEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for WebhookEvents.
     */
    cursor?: Prisma.WebhookEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` WebhookEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` WebhookEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of WebhookEvents.
     */
    distinct?: Prisma.WebhookEventScalarFieldEnum | Prisma.WebhookEventScalarFieldEnum[];
};
/**
 * WebhookEvent findMany
 */
export type WebhookEventFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * Filter, which WebhookEvents to fetch.
     */
    where?: Prisma.WebhookEventWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of WebhookEvents to fetch.
     */
    orderBy?: Prisma.WebhookEventOrderByWithRelationInput | Prisma.WebhookEventOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for listing WebhookEvents.
     */
    cursor?: Prisma.WebhookEventWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` WebhookEvents from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` WebhookEvents.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of WebhookEvents.
     */
    distinct?: Prisma.WebhookEventScalarFieldEnum | Prisma.WebhookEventScalarFieldEnum[];
};
/**
 * WebhookEvent create
 */
export type WebhookEventCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * The data needed to create a WebhookEvent.
     */
    data: Prisma.XOR<Prisma.WebhookEventCreateInput, Prisma.WebhookEventUncheckedCreateInput>;
};
/**
 * WebhookEvent createMany
 */
export type WebhookEventCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to create many WebhookEvents.
     */
    data: Prisma.WebhookEventCreateManyInput | Prisma.WebhookEventCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * WebhookEvent createManyAndReturn
 */
export type WebhookEventCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelectCreateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * The data used to create many WebhookEvents.
     */
    data: Prisma.WebhookEventCreateManyInput | Prisma.WebhookEventCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * WebhookEvent update
 */
export type WebhookEventUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * The data needed to update a WebhookEvent.
     */
    data: Prisma.XOR<Prisma.WebhookEventUpdateInput, Prisma.WebhookEventUncheckedUpdateInput>;
    /**
     * Choose, which WebhookEvent to update.
     */
    where: Prisma.WebhookEventWhereUniqueInput;
};
/**
 * WebhookEvent updateMany
 */
export type WebhookEventUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to update WebhookEvents.
     */
    data: Prisma.XOR<Prisma.WebhookEventUpdateManyMutationInput, Prisma.WebhookEventUncheckedUpdateManyInput>;
    /**
     * Filter which WebhookEvents to update
     */
    where?: Prisma.WebhookEventWhereInput;
    /**
     * Limit how many WebhookEvents to update.
     */
    limit?: number;
};
/**
 * WebhookEvent updateManyAndReturn
 */
export type WebhookEventUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelectUpdateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * The data used to update WebhookEvents.
     */
    data: Prisma.XOR<Prisma.WebhookEventUpdateManyMutationInput, Prisma.WebhookEventUncheckedUpdateManyInput>;
    /**
     * Filter which WebhookEvents to update
     */
    where?: Prisma.WebhookEventWhereInput;
    /**
     * Limit how many WebhookEvents to update.
     */
    limit?: number;
};
/**
 * WebhookEvent upsert
 */
export type WebhookEventUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * The filter to search for the WebhookEvent to update in case it exists.
     */
    where: Prisma.WebhookEventWhereUniqueInput;
    /**
     * In case the WebhookEvent found by the `where` argument doesn't exist, create a new WebhookEvent with this data.
     */
    create: Prisma.XOR<Prisma.WebhookEventCreateInput, Prisma.WebhookEventUncheckedCreateInput>;
    /**
     * In case the WebhookEvent was found with the provided `where` argument, update it with this data.
     */
    update: Prisma.XOR<Prisma.WebhookEventUpdateInput, Prisma.WebhookEventUncheckedUpdateInput>;
};
/**
 * WebhookEvent delete
 */
export type WebhookEventDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
    /**
     * Filter which WebhookEvent to delete.
     */
    where: Prisma.WebhookEventWhereUniqueInput;
};
/**
 * WebhookEvent deleteMany
 */
export type WebhookEventDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which WebhookEvents to delete
     */
    where?: Prisma.WebhookEventWhereInput;
    /**
     * Limit how many WebhookEvents to delete.
     */
    limit?: number;
};
/**
 * WebhookEvent without action
 */
export type WebhookEventDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the WebhookEvent
     */
    select?: Prisma.WebhookEventSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the WebhookEvent
     */
    omit?: Prisma.WebhookEventOmit<ExtArgs> | null;
};
//# sourceMappingURL=WebhookEvent.d.ts.map