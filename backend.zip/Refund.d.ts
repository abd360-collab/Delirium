import type * as runtime from "@prisma/client/runtime/client";
import type * as $Enums from "../enums.js";
import type * as Prisma from "../internal/prismaNamespace.js";
/**
 * Model Refund
 *
 */
export type RefundModel = runtime.Types.Result.DefaultSelection<Prisma.$RefundPayload>;
export type AggregateRefund = {
    _count: RefundCountAggregateOutputType | null;
    _avg: RefundAvgAggregateOutputType | null;
    _sum: RefundSumAggregateOutputType | null;
    _min: RefundMinAggregateOutputType | null;
    _max: RefundMaxAggregateOutputType | null;
};
export type RefundAvgAggregateOutputType = {
    amountInPaise: number | null;
};
export type RefundSumAggregateOutputType = {
    amountInPaise: number | null;
};
export type RefundMinAggregateOutputType = {
    id: string | null;
    paymentId: string | null;
    amountInPaise: number | null;
    status: $Enums.RefundStatus | null;
    gatewayRefundId: string | null;
    gatewayPaymentId: string | null;
    reason: string | null;
    createdAt: Date | null;
    updatedAt: Date | null;
    idempotencyKey: string | null;
};
export type RefundMaxAggregateOutputType = {
    id: string | null;
    paymentId: string | null;
    amountInPaise: number | null;
    status: $Enums.RefundStatus | null;
    gatewayRefundId: string | null;
    gatewayPaymentId: string | null;
    reason: string | null;
    createdAt: Date | null;
    updatedAt: Date | null;
    idempotencyKey: string | null;
};
export type RefundCountAggregateOutputType = {
    id: number;
    paymentId: number;
    amountInPaise: number;
    status: number;
    gatewayRefundId: number;
    gatewayPaymentId: number;
    reason: number;
    createdAt: number;
    updatedAt: number;
    idempotencyKey: number;
    _all: number;
};
export type RefundAvgAggregateInputType = {
    amountInPaise?: true;
};
export type RefundSumAggregateInputType = {
    amountInPaise?: true;
};
export type RefundMinAggregateInputType = {
    id?: true;
    paymentId?: true;
    amountInPaise?: true;
    status?: true;
    gatewayRefundId?: true;
    gatewayPaymentId?: true;
    reason?: true;
    createdAt?: true;
    updatedAt?: true;
    idempotencyKey?: true;
};
export type RefundMaxAggregateInputType = {
    id?: true;
    paymentId?: true;
    amountInPaise?: true;
    status?: true;
    gatewayRefundId?: true;
    gatewayPaymentId?: true;
    reason?: true;
    createdAt?: true;
    updatedAt?: true;
    idempotencyKey?: true;
};
export type RefundCountAggregateInputType = {
    id?: true;
    paymentId?: true;
    amountInPaise?: true;
    status?: true;
    gatewayRefundId?: true;
    gatewayPaymentId?: true;
    reason?: true;
    createdAt?: true;
    updatedAt?: true;
    idempotencyKey?: true;
    _all?: true;
};
export type RefundAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which Refund to aggregate.
     */
    where?: Prisma.RefundWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Refunds to fetch.
     */
    orderBy?: Prisma.RefundOrderByWithRelationInput | Prisma.RefundOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the start position
     */
    cursor?: Prisma.RefundWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Refunds from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Refunds.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Count returned Refunds
    **/
    _count?: true | RefundCountAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to average
    **/
    _avg?: RefundAvgAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to sum
    **/
    _sum?: RefundSumAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the minimum value
    **/
    _min?: RefundMinAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the maximum value
    **/
    _max?: RefundMaxAggregateInputType;
};
export type GetRefundAggregateType<T extends RefundAggregateArgs> = {
    [P in keyof T & keyof AggregateRefund]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateRefund[P]> : Prisma.GetScalarType<T[P], AggregateRefund[P]>;
};
export type RefundGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.RefundWhereInput;
    orderBy?: Prisma.RefundOrderByWithAggregationInput | Prisma.RefundOrderByWithAggregationInput[];
    by: Prisma.RefundScalarFieldEnum[] | Prisma.RefundScalarFieldEnum;
    having?: Prisma.RefundScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: RefundCountAggregateInputType | true;
    _avg?: RefundAvgAggregateInputType;
    _sum?: RefundSumAggregateInputType;
    _min?: RefundMinAggregateInputType;
    _max?: RefundMaxAggregateInputType;
};
export type RefundGroupByOutputType = {
    id: string;
    paymentId: string;
    amountInPaise: number;
    status: $Enums.RefundStatus;
    gatewayRefundId: string | null;
    gatewayPaymentId: string;
    reason: string | null;
    createdAt: Date;
    updatedAt: Date;
    idempotencyKey: string;
    _count: RefundCountAggregateOutputType | null;
    _avg: RefundAvgAggregateOutputType | null;
    _sum: RefundSumAggregateOutputType | null;
    _min: RefundMinAggregateOutputType | null;
    _max: RefundMaxAggregateOutputType | null;
};
export type GetRefundGroupByPayload<T extends RefundGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<RefundGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof RefundGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], RefundGroupByOutputType[P]> : Prisma.GetScalarType<T[P], RefundGroupByOutputType[P]>;
}>>;
export type RefundWhereInput = {
    AND?: Prisma.RefundWhereInput | Prisma.RefundWhereInput[];
    OR?: Prisma.RefundWhereInput[];
    NOT?: Prisma.RefundWhereInput | Prisma.RefundWhereInput[];
    id?: Prisma.StringFilter<"Refund"> | string;
    paymentId?: Prisma.StringFilter<"Refund"> | string;
    amountInPaise?: Prisma.IntFilter<"Refund"> | number;
    status?: Prisma.EnumRefundStatusFilter<"Refund"> | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.StringNullableFilter<"Refund"> | string | null;
    gatewayPaymentId?: Prisma.StringFilter<"Refund"> | string;
    reason?: Prisma.StringNullableFilter<"Refund"> | string | null;
    createdAt?: Prisma.DateTimeFilter<"Refund"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"Refund"> | Date | string;
    idempotencyKey?: Prisma.StringFilter<"Refund"> | string;
    payment?: Prisma.XOR<Prisma.PaymentScalarRelationFilter, Prisma.PaymentWhereInput>;
};
export type RefundOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayRefundId?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    reason?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    idempotencyKey?: Prisma.SortOrder;
    payment?: Prisma.PaymentOrderByWithRelationInput;
};
export type RefundWhereUniqueInput = Prisma.AtLeast<{
    id?: string;
    gatewayRefundId?: string;
    idempotencyKey?: string;
    AND?: Prisma.RefundWhereInput | Prisma.RefundWhereInput[];
    OR?: Prisma.RefundWhereInput[];
    NOT?: Prisma.RefundWhereInput | Prisma.RefundWhereInput[];
    paymentId?: Prisma.StringFilter<"Refund"> | string;
    amountInPaise?: Prisma.IntFilter<"Refund"> | number;
    status?: Prisma.EnumRefundStatusFilter<"Refund"> | $Enums.RefundStatus;
    gatewayPaymentId?: Prisma.StringFilter<"Refund"> | string;
    reason?: Prisma.StringNullableFilter<"Refund"> | string | null;
    createdAt?: Prisma.DateTimeFilter<"Refund"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"Refund"> | Date | string;
    payment?: Prisma.XOR<Prisma.PaymentScalarRelationFilter, Prisma.PaymentWhereInput>;
}, "id" | "gatewayRefundId" | "idempotencyKey">;
export type RefundOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayRefundId?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    reason?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    idempotencyKey?: Prisma.SortOrder;
    _count?: Prisma.RefundCountOrderByAggregateInput;
    _avg?: Prisma.RefundAvgOrderByAggregateInput;
    _max?: Prisma.RefundMaxOrderByAggregateInput;
    _min?: Prisma.RefundMinOrderByAggregateInput;
    _sum?: Prisma.RefundSumOrderByAggregateInput;
};
export type RefundScalarWhereWithAggregatesInput = {
    AND?: Prisma.RefundScalarWhereWithAggregatesInput | Prisma.RefundScalarWhereWithAggregatesInput[];
    OR?: Prisma.RefundScalarWhereWithAggregatesInput[];
    NOT?: Prisma.RefundScalarWhereWithAggregatesInput | Prisma.RefundScalarWhereWithAggregatesInput[];
    id?: Prisma.StringWithAggregatesFilter<"Refund"> | string;
    paymentId?: Prisma.StringWithAggregatesFilter<"Refund"> | string;
    amountInPaise?: Prisma.IntWithAggregatesFilter<"Refund"> | number;
    status?: Prisma.EnumRefundStatusWithAggregatesFilter<"Refund"> | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.StringNullableWithAggregatesFilter<"Refund"> | string | null;
    gatewayPaymentId?: Prisma.StringWithAggregatesFilter<"Refund"> | string;
    reason?: Prisma.StringNullableWithAggregatesFilter<"Refund"> | string | null;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"Refund"> | Date | string;
    updatedAt?: Prisma.DateTimeWithAggregatesFilter<"Refund"> | Date | string;
    idempotencyKey?: Prisma.StringWithAggregatesFilter<"Refund"> | string;
};
export type RefundCreateInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.RefundStatus;
    gatewayRefundId?: string | null;
    gatewayPaymentId: string;
    reason?: string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    idempotencyKey: string;
    payment: Prisma.PaymentCreateNestedOneWithoutRefundsInput;
};
export type RefundUncheckedCreateInput = {
    id?: string;
    paymentId: string;
    amountInPaise: number;
    status?: $Enums.RefundStatus;
    gatewayRefundId?: string | null;
    gatewayPaymentId: string;
    reason?: string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    idempotencyKey: string;
};
export type RefundUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumRefundStatusFieldUpdateOperationsInput | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    reason?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    idempotencyKey?: Prisma.StringFieldUpdateOperationsInput | string;
    payment?: Prisma.PaymentUpdateOneRequiredWithoutRefundsNestedInput;
};
export type RefundUncheckedUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    paymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumRefundStatusFieldUpdateOperationsInput | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    reason?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    idempotencyKey?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type RefundCreateManyInput = {
    id?: string;
    paymentId: string;
    amountInPaise: number;
    status?: $Enums.RefundStatus;
    gatewayRefundId?: string | null;
    gatewayPaymentId: string;
    reason?: string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    idempotencyKey: string;
};
export type RefundUpdateManyMutationInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumRefundStatusFieldUpdateOperationsInput | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    reason?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    idempotencyKey?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type RefundUncheckedUpdateManyInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    paymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumRefundStatusFieldUpdateOperationsInput | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    reason?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    idempotencyKey?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type RefundListRelationFilter = {
    every?: Prisma.RefundWhereInput;
    some?: Prisma.RefundWhereInput;
    none?: Prisma.RefundWhereInput;
};
export type RefundOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type RefundCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayRefundId?: Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    reason?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    idempotencyKey?: Prisma.SortOrder;
};
export type RefundAvgOrderByAggregateInput = {
    amountInPaise?: Prisma.SortOrder;
};
export type RefundMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayRefundId?: Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    reason?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    idempotencyKey?: Prisma.SortOrder;
};
export type RefundMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayRefundId?: Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    reason?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    idempotencyKey?: Prisma.SortOrder;
};
export type RefundSumOrderByAggregateInput = {
    amountInPaise?: Prisma.SortOrder;
};
export type RefundCreateNestedManyWithoutPaymentInput = {
    create?: Prisma.XOR<Prisma.RefundCreateWithoutPaymentInput, Prisma.RefundUncheckedCreateWithoutPaymentInput> | Prisma.RefundCreateWithoutPaymentInput[] | Prisma.RefundUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.RefundCreateOrConnectWithoutPaymentInput | Prisma.RefundCreateOrConnectWithoutPaymentInput[];
    createMany?: Prisma.RefundCreateManyPaymentInputEnvelope;
    connect?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
};
export type RefundUncheckedCreateNestedManyWithoutPaymentInput = {
    create?: Prisma.XOR<Prisma.RefundCreateWithoutPaymentInput, Prisma.RefundUncheckedCreateWithoutPaymentInput> | Prisma.RefundCreateWithoutPaymentInput[] | Prisma.RefundUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.RefundCreateOrConnectWithoutPaymentInput | Prisma.RefundCreateOrConnectWithoutPaymentInput[];
    createMany?: Prisma.RefundCreateManyPaymentInputEnvelope;
    connect?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
};
export type RefundUpdateManyWithoutPaymentNestedInput = {
    create?: Prisma.XOR<Prisma.RefundCreateWithoutPaymentInput, Prisma.RefundUncheckedCreateWithoutPaymentInput> | Prisma.RefundCreateWithoutPaymentInput[] | Prisma.RefundUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.RefundCreateOrConnectWithoutPaymentInput | Prisma.RefundCreateOrConnectWithoutPaymentInput[];
    upsert?: Prisma.RefundUpsertWithWhereUniqueWithoutPaymentInput | Prisma.RefundUpsertWithWhereUniqueWithoutPaymentInput[];
    createMany?: Prisma.RefundCreateManyPaymentInputEnvelope;
    set?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    disconnect?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    delete?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    connect?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    update?: Prisma.RefundUpdateWithWhereUniqueWithoutPaymentInput | Prisma.RefundUpdateWithWhereUniqueWithoutPaymentInput[];
    updateMany?: Prisma.RefundUpdateManyWithWhereWithoutPaymentInput | Prisma.RefundUpdateManyWithWhereWithoutPaymentInput[];
    deleteMany?: Prisma.RefundScalarWhereInput | Prisma.RefundScalarWhereInput[];
};
export type RefundUncheckedUpdateManyWithoutPaymentNestedInput = {
    create?: Prisma.XOR<Prisma.RefundCreateWithoutPaymentInput, Prisma.RefundUncheckedCreateWithoutPaymentInput> | Prisma.RefundCreateWithoutPaymentInput[] | Prisma.RefundUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.RefundCreateOrConnectWithoutPaymentInput | Prisma.RefundCreateOrConnectWithoutPaymentInput[];
    upsert?: Prisma.RefundUpsertWithWhereUniqueWithoutPaymentInput | Prisma.RefundUpsertWithWhereUniqueWithoutPaymentInput[];
    createMany?: Prisma.RefundCreateManyPaymentInputEnvelope;
    set?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    disconnect?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    delete?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    connect?: Prisma.RefundWhereUniqueInput | Prisma.RefundWhereUniqueInput[];
    update?: Prisma.RefundUpdateWithWhereUniqueWithoutPaymentInput | Prisma.RefundUpdateWithWhereUniqueWithoutPaymentInput[];
    updateMany?: Prisma.RefundUpdateManyWithWhereWithoutPaymentInput | Prisma.RefundUpdateManyWithWhereWithoutPaymentInput[];
    deleteMany?: Prisma.RefundScalarWhereInput | Prisma.RefundScalarWhereInput[];
};
export type EnumRefundStatusFieldUpdateOperationsInput = {
    set?: $Enums.RefundStatus;
};
export type RefundCreateWithoutPaymentInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.RefundStatus;
    gatewayRefundId?: string | null;
    gatewayPaymentId: string;
    reason?: string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    idempotencyKey: string;
};
export type RefundUncheckedCreateWithoutPaymentInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.RefundStatus;
    gatewayRefundId?: string | null;
    gatewayPaymentId: string;
    reason?: string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    idempotencyKey: string;
};
export type RefundCreateOrConnectWithoutPaymentInput = {
    where: Prisma.RefundWhereUniqueInput;
    create: Prisma.XOR<Prisma.RefundCreateWithoutPaymentInput, Prisma.RefundUncheckedCreateWithoutPaymentInput>;
};
export type RefundCreateManyPaymentInputEnvelope = {
    data: Prisma.RefundCreateManyPaymentInput | Prisma.RefundCreateManyPaymentInput[];
    skipDuplicates?: boolean;
};
export type RefundUpsertWithWhereUniqueWithoutPaymentInput = {
    where: Prisma.RefundWhereUniqueInput;
    update: Prisma.XOR<Prisma.RefundUpdateWithoutPaymentInput, Prisma.RefundUncheckedUpdateWithoutPaymentInput>;
    create: Prisma.XOR<Prisma.RefundCreateWithoutPaymentInput, Prisma.RefundUncheckedCreateWithoutPaymentInput>;
};
export type RefundUpdateWithWhereUniqueWithoutPaymentInput = {
    where: Prisma.RefundWhereUniqueInput;
    data: Prisma.XOR<Prisma.RefundUpdateWithoutPaymentInput, Prisma.RefundUncheckedUpdateWithoutPaymentInput>;
};
export type RefundUpdateManyWithWhereWithoutPaymentInput = {
    where: Prisma.RefundScalarWhereInput;
    data: Prisma.XOR<Prisma.RefundUpdateManyMutationInput, Prisma.RefundUncheckedUpdateManyWithoutPaymentInput>;
};
export type RefundScalarWhereInput = {
    AND?: Prisma.RefundScalarWhereInput | Prisma.RefundScalarWhereInput[];
    OR?: Prisma.RefundScalarWhereInput[];
    NOT?: Prisma.RefundScalarWhereInput | Prisma.RefundScalarWhereInput[];
    id?: Prisma.StringFilter<"Refund"> | string;
    paymentId?: Prisma.StringFilter<"Refund"> | string;
    amountInPaise?: Prisma.IntFilter<"Refund"> | number;
    status?: Prisma.EnumRefundStatusFilter<"Refund"> | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.StringNullableFilter<"Refund"> | string | null;
    gatewayPaymentId?: Prisma.StringFilter<"Refund"> | string;
    reason?: Prisma.StringNullableFilter<"Refund"> | string | null;
    createdAt?: Prisma.DateTimeFilter<"Refund"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"Refund"> | Date | string;
    idempotencyKey?: Prisma.StringFilter<"Refund"> | string;
};
export type RefundCreateManyPaymentInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.RefundStatus;
    gatewayRefundId?: string | null;
    gatewayPaymentId: string;
    reason?: string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    idempotencyKey: string;
};
export type RefundUpdateWithoutPaymentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumRefundStatusFieldUpdateOperationsInput | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    reason?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    idempotencyKey?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type RefundUncheckedUpdateWithoutPaymentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumRefundStatusFieldUpdateOperationsInput | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    reason?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    idempotencyKey?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type RefundUncheckedUpdateManyWithoutPaymentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumRefundStatusFieldUpdateOperationsInput | $Enums.RefundStatus;
    gatewayRefundId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    reason?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    idempotencyKey?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type RefundSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayRefundId?: boolean;
    gatewayPaymentId?: boolean;
    reason?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    idempotencyKey?: boolean;
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["refund"]>;
export type RefundSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayRefundId?: boolean;
    gatewayPaymentId?: boolean;
    reason?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    idempotencyKey?: boolean;
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["refund"]>;
export type RefundSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayRefundId?: boolean;
    gatewayPaymentId?: boolean;
    reason?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    idempotencyKey?: boolean;
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["refund"]>;
export type RefundSelectScalar = {
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayRefundId?: boolean;
    gatewayPaymentId?: boolean;
    reason?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    idempotencyKey?: boolean;
};
export type RefundOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "paymentId" | "amountInPaise" | "status" | "gatewayRefundId" | "gatewayPaymentId" | "reason" | "createdAt" | "updatedAt" | "idempotencyKey", ExtArgs["result"]["refund"]>;
export type RefundInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
};
export type RefundIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
};
export type RefundIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
};
export type $RefundPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "Refund";
    objects: {
        payment: Prisma.$PaymentPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: string;
        paymentId: string;
        amountInPaise: number;
        status: $Enums.RefundStatus;
        gatewayRefundId: string | null;
        gatewayPaymentId: string;
        reason: string | null;
        createdAt: Date;
        updatedAt: Date;
        idempotencyKey: string;
    }, ExtArgs["result"]["refund"]>;
    composites: {};
};
export type RefundGetPayload<S extends boolean | null | undefined | RefundDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$RefundPayload, S>;
export type RefundCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<RefundFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: RefundCountAggregateInputType | true;
};
export interface RefundDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['Refund'];
        meta: {
            name: 'Refund';
        };
    };
    /**
     * Find zero or one Refund that matches the filter.
     * @param {RefundFindUniqueArgs} args - Arguments to find a Refund
     * @example
     * // Get one Refund
     * const refund = await prisma.refund.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends RefundFindUniqueArgs>(args: Prisma.SelectSubset<T, RefundFindUniqueArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find one Refund that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {RefundFindUniqueOrThrowArgs} args - Arguments to find a Refund
     * @example
     * // Get one Refund
     * const refund = await prisma.refund.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends RefundFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, RefundFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first Refund that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefundFindFirstArgs} args - Arguments to find a Refund
     * @example
     * // Get one Refund
     * const refund = await prisma.refund.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends RefundFindFirstArgs>(args?: Prisma.SelectSubset<T, RefundFindFirstArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first Refund that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefundFindFirstOrThrowArgs} args - Arguments to find a Refund
     * @example
     * // Get one Refund
     * const refund = await prisma.refund.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends RefundFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, RefundFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find zero or more Refunds that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefundFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Refunds
     * const refunds = await prisma.refund.findMany()
     *
     * // Get first 10 Refunds
     * const refunds = await prisma.refund.findMany({ take: 10 })
     *
     * // Only select the `id`
     * const refundWithIdOnly = await prisma.refund.findMany({ select: { id: true } })
     *
     */
    findMany<T extends RefundFindManyArgs>(args?: Prisma.SelectSubset<T, RefundFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    /**
     * Create a Refund.
     * @param {RefundCreateArgs} args - Arguments to create a Refund.
     * @example
     * // Create one Refund
     * const Refund = await prisma.refund.create({
     *   data: {
     *     // ... data to create a Refund
     *   }
     * })
     *
     */
    create<T extends RefundCreateArgs>(args: Prisma.SelectSubset<T, RefundCreateArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Create many Refunds.
     * @param {RefundCreateManyArgs} args - Arguments to create many Refunds.
     * @example
     * // Create many Refunds
     * const refund = await prisma.refund.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     */
    createMany<T extends RefundCreateManyArgs>(args?: Prisma.SelectSubset<T, RefundCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Create many Refunds and returns the data saved in the database.
     * @param {RefundCreateManyAndReturnArgs} args - Arguments to create many Refunds.
     * @example
     * // Create many Refunds
     * const refund = await prisma.refund.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Create many Refunds and only return the `id`
     * const refundWithIdOnly = await prisma.refund.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    createManyAndReturn<T extends RefundCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, RefundCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    /**
     * Delete a Refund.
     * @param {RefundDeleteArgs} args - Arguments to delete one Refund.
     * @example
     * // Delete one Refund
     * const Refund = await prisma.refund.delete({
     *   where: {
     *     // ... filter to delete one Refund
     *   }
     * })
     *
     */
    delete<T extends RefundDeleteArgs>(args: Prisma.SelectSubset<T, RefundDeleteArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Update one Refund.
     * @param {RefundUpdateArgs} args - Arguments to update one Refund.
     * @example
     * // Update one Refund
     * const refund = await prisma.refund.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    update<T extends RefundUpdateArgs>(args: Prisma.SelectSubset<T, RefundUpdateArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Delete zero or more Refunds.
     * @param {RefundDeleteManyArgs} args - Arguments to filter Refunds to delete.
     * @example
     * // Delete a few Refunds
     * const { count } = await prisma.refund.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     *
     */
    deleteMany<T extends RefundDeleteManyArgs>(args?: Prisma.SelectSubset<T, RefundDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more Refunds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefundUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Refunds
     * const refund = await prisma.refund.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    updateMany<T extends RefundUpdateManyArgs>(args: Prisma.SelectSubset<T, RefundUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more Refunds and returns the data updated in the database.
     * @param {RefundUpdateManyAndReturnArgs} args - Arguments to update many Refunds.
     * @example
     * // Update many Refunds
     * const refund = await prisma.refund.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Update zero or more Refunds and only return the `id`
     * const refundWithIdOnly = await prisma.refund.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    updateManyAndReturn<T extends RefundUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, RefundUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    /**
     * Create or update one Refund.
     * @param {RefundUpsertArgs} args - Arguments to update or create a Refund.
     * @example
     * // Update or create a Refund
     * const refund = await prisma.refund.upsert({
     *   create: {
     *     // ... data to create a Refund
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Refund we want to update
     *   }
     * })
     */
    upsert<T extends RefundUpsertArgs>(args: Prisma.SelectSubset<T, RefundUpsertArgs<ExtArgs>>): Prisma.Prisma__RefundClient<runtime.Types.Result.GetResult<Prisma.$RefundPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Count the number of Refunds.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefundCountArgs} args - Arguments to filter Refunds to count.
     * @example
     * // Count the number of Refunds
     * const count = await prisma.refund.count({
     *   where: {
     *     // ... the filter for the Refunds we want to count
     *   }
     * })
    **/
    count<T extends RefundCountArgs>(args?: Prisma.Subset<T, RefundCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], RefundCountAggregateOutputType> : number>;
    /**
     * Allows you to perform aggregations operations on a Refund.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefundAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends RefundAggregateArgs>(args: Prisma.Subset<T, RefundAggregateArgs>): Prisma.PrismaPromise<GetRefundAggregateType<T>>;
    /**
     * Group by Refund.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {RefundGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     *
    **/
    groupBy<T extends RefundGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: RefundGroupByArgs['orderBy'];
    } : {
        orderBy?: RefundGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, RefundGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRefundGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    /**
     * Fields of the Refund model
     */
    readonly fields: RefundFieldRefs;
}
/**
 * The delegate class that acts as a "Promise-like" for Refund.
 * Why is this prefixed with `Prisma__`?
 * Because we want to prevent naming conflicts as mentioned in
 * https://github.com/prisma/prisma-client-js/issues/707
 */
export interface Prisma__RefundClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    payment<T extends Prisma.PaymentDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.PaymentDefaultArgs<ExtArgs>>): Prisma.Prisma__PaymentClient<runtime.Types.Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
/**
 * Fields of the Refund model
 */
export interface RefundFieldRefs {
    readonly id: Prisma.FieldRef<"Refund", 'String'>;
    readonly paymentId: Prisma.FieldRef<"Refund", 'String'>;
    readonly amountInPaise: Prisma.FieldRef<"Refund", 'Int'>;
    readonly status: Prisma.FieldRef<"Refund", 'RefundStatus'>;
    readonly gatewayRefundId: Prisma.FieldRef<"Refund", 'String'>;
    readonly gatewayPaymentId: Prisma.FieldRef<"Refund", 'String'>;
    readonly reason: Prisma.FieldRef<"Refund", 'String'>;
    readonly createdAt: Prisma.FieldRef<"Refund", 'DateTime'>;
    readonly updatedAt: Prisma.FieldRef<"Refund", 'DateTime'>;
    readonly idempotencyKey: Prisma.FieldRef<"Refund", 'String'>;
}
/**
 * Refund findUnique
 */
export type RefundFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * Filter, which Refund to fetch.
     */
    where: Prisma.RefundWhereUniqueInput;
};
/**
 * Refund findUniqueOrThrow
 */
export type RefundFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * Filter, which Refund to fetch.
     */
    where: Prisma.RefundWhereUniqueInput;
};
/**
 * Refund findFirst
 */
export type RefundFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * Filter, which Refund to fetch.
     */
    where?: Prisma.RefundWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Refunds to fetch.
     */
    orderBy?: Prisma.RefundOrderByWithRelationInput | Prisma.RefundOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for Refunds.
     */
    cursor?: Prisma.RefundWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Refunds from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Refunds.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of Refunds.
     */
    distinct?: Prisma.RefundScalarFieldEnum | Prisma.RefundScalarFieldEnum[];
};
/**
 * Refund findFirstOrThrow
 */
export type RefundFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * Filter, which Refund to fetch.
     */
    where?: Prisma.RefundWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Refunds to fetch.
     */
    orderBy?: Prisma.RefundOrderByWithRelationInput | Prisma.RefundOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for Refunds.
     */
    cursor?: Prisma.RefundWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Refunds from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Refunds.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of Refunds.
     */
    distinct?: Prisma.RefundScalarFieldEnum | Prisma.RefundScalarFieldEnum[];
};
/**
 * Refund findMany
 */
export type RefundFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * Filter, which Refunds to fetch.
     */
    where?: Prisma.RefundWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of Refunds to fetch.
     */
    orderBy?: Prisma.RefundOrderByWithRelationInput | Prisma.RefundOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for listing Refunds.
     */
    cursor?: Prisma.RefundWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` Refunds from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` Refunds.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of Refunds.
     */
    distinct?: Prisma.RefundScalarFieldEnum | Prisma.RefundScalarFieldEnum[];
};
/**
 * Refund create
 */
export type RefundCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * The data needed to create a Refund.
     */
    data: Prisma.XOR<Prisma.RefundCreateInput, Prisma.RefundUncheckedCreateInput>;
};
/**
 * Refund createMany
 */
export type RefundCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to create many Refunds.
     */
    data: Prisma.RefundCreateManyInput | Prisma.RefundCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * Refund createManyAndReturn
 */
export type RefundCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelectCreateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * The data used to create many Refunds.
     */
    data: Prisma.RefundCreateManyInput | Prisma.RefundCreateManyInput[];
    skipDuplicates?: boolean;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundIncludeCreateManyAndReturn<ExtArgs> | null;
};
/**
 * Refund update
 */
export type RefundUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * The data needed to update a Refund.
     */
    data: Prisma.XOR<Prisma.RefundUpdateInput, Prisma.RefundUncheckedUpdateInput>;
    /**
     * Choose, which Refund to update.
     */
    where: Prisma.RefundWhereUniqueInput;
};
/**
 * Refund updateMany
 */
export type RefundUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to update Refunds.
     */
    data: Prisma.XOR<Prisma.RefundUpdateManyMutationInput, Prisma.RefundUncheckedUpdateManyInput>;
    /**
     * Filter which Refunds to update
     */
    where?: Prisma.RefundWhereInput;
    /**
     * Limit how many Refunds to update.
     */
    limit?: number;
};
/**
 * Refund updateManyAndReturn
 */
export type RefundUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelectUpdateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * The data used to update Refunds.
     */
    data: Prisma.XOR<Prisma.RefundUpdateManyMutationInput, Prisma.RefundUncheckedUpdateManyInput>;
    /**
     * Filter which Refunds to update
     */
    where?: Prisma.RefundWhereInput;
    /**
     * Limit how many Refunds to update.
     */
    limit?: number;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundIncludeUpdateManyAndReturn<ExtArgs> | null;
};
/**
 * Refund upsert
 */
export type RefundUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * The filter to search for the Refund to update in case it exists.
     */
    where: Prisma.RefundWhereUniqueInput;
    /**
     * In case the Refund found by the `where` argument doesn't exist, create a new Refund with this data.
     */
    create: Prisma.XOR<Prisma.RefundCreateInput, Prisma.RefundUncheckedCreateInput>;
    /**
     * In case the Refund was found with the provided `where` argument, update it with this data.
     */
    update: Prisma.XOR<Prisma.RefundUpdateInput, Prisma.RefundUncheckedUpdateInput>;
};
/**
 * Refund delete
 */
export type RefundDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
    /**
     * Filter which Refund to delete.
     */
    where: Prisma.RefundWhereUniqueInput;
};
/**
 * Refund deleteMany
 */
export type RefundDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which Refunds to delete
     */
    where?: Prisma.RefundWhereInput;
    /**
     * Limit how many Refunds to delete.
     */
    limit?: number;
};
/**
 * Refund without action
 */
export type RefundDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Refund
     */
    select?: Prisma.RefundSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the Refund
     */
    omit?: Prisma.RefundOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.RefundInclude<ExtArgs> | null;
};
//# sourceMappingURL=Refund.d.ts.map