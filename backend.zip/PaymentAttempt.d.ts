import type * as runtime from "@prisma/client/runtime/client";
import type * as $Enums from "../enums.js";
import type * as Prisma from "../internal/prismaNamespace.js";
/**
 * Model PaymentAttempt
 *
 */
export type PaymentAttemptModel = runtime.Types.Result.DefaultSelection<Prisma.$PaymentAttemptPayload>;
export type AggregatePaymentAttempt = {
    _count: PaymentAttemptCountAggregateOutputType | null;
    _avg: PaymentAttemptAvgAggregateOutputType | null;
    _sum: PaymentAttemptSumAggregateOutputType | null;
    _min: PaymentAttemptMinAggregateOutputType | null;
    _max: PaymentAttemptMaxAggregateOutputType | null;
};
export type PaymentAttemptAvgAggregateOutputType = {
    amountInPaise: number | null;
};
export type PaymentAttemptSumAggregateOutputType = {
    amountInPaise: number | null;
};
export type PaymentAttemptMinAggregateOutputType = {
    id: string | null;
    paymentId: string | null;
    amountInPaise: number | null;
    status: $Enums.PaymentAttemptStatus | null;
    gatewayOrderId: string | null;
    gatewayPaymentId: string | null;
    gatewaySignature: string | null;
    gatewayOrderCreatedAt: Date | null;
    gatewayOrderCreationToken: string | null;
    gatewayOrderCreationUntil: Date | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type PaymentAttemptMaxAggregateOutputType = {
    id: string | null;
    paymentId: string | null;
    amountInPaise: number | null;
    status: $Enums.PaymentAttemptStatus | null;
    gatewayOrderId: string | null;
    gatewayPaymentId: string | null;
    gatewaySignature: string | null;
    gatewayOrderCreatedAt: Date | null;
    gatewayOrderCreationToken: string | null;
    gatewayOrderCreationUntil: Date | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type PaymentAttemptCountAggregateOutputType = {
    id: number;
    paymentId: number;
    amountInPaise: number;
    status: number;
    gatewayOrderId: number;
    gatewayPaymentId: number;
    gatewaySignature: number;
    gatewayOrderCreatedAt: number;
    gatewayOrderCreationToken: number;
    gatewayOrderCreationUntil: number;
    createdAt: number;
    updatedAt: number;
    _all: number;
};
export type PaymentAttemptAvgAggregateInputType = {
    amountInPaise?: true;
};
export type PaymentAttemptSumAggregateInputType = {
    amountInPaise?: true;
};
export type PaymentAttemptMinAggregateInputType = {
    id?: true;
    paymentId?: true;
    amountInPaise?: true;
    status?: true;
    gatewayOrderId?: true;
    gatewayPaymentId?: true;
    gatewaySignature?: true;
    gatewayOrderCreatedAt?: true;
    gatewayOrderCreationToken?: true;
    gatewayOrderCreationUntil?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type PaymentAttemptMaxAggregateInputType = {
    id?: true;
    paymentId?: true;
    amountInPaise?: true;
    status?: true;
    gatewayOrderId?: true;
    gatewayPaymentId?: true;
    gatewaySignature?: true;
    gatewayOrderCreatedAt?: true;
    gatewayOrderCreationToken?: true;
    gatewayOrderCreationUntil?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type PaymentAttemptCountAggregateInputType = {
    id?: true;
    paymentId?: true;
    amountInPaise?: true;
    status?: true;
    gatewayOrderId?: true;
    gatewayPaymentId?: true;
    gatewaySignature?: true;
    gatewayOrderCreatedAt?: true;
    gatewayOrderCreationToken?: true;
    gatewayOrderCreationUntil?: true;
    createdAt?: true;
    updatedAt?: true;
    _all?: true;
};
export type PaymentAttemptAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which PaymentAttempt to aggregate.
     */
    where?: Prisma.PaymentAttemptWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of PaymentAttempts to fetch.
     */
    orderBy?: Prisma.PaymentAttemptOrderByWithRelationInput | Prisma.PaymentAttemptOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the start position
     */
    cursor?: Prisma.PaymentAttemptWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` PaymentAttempts from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` PaymentAttempts.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Count returned PaymentAttempts
    **/
    _count?: true | PaymentAttemptCountAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to average
    **/
    _avg?: PaymentAttemptAvgAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to sum
    **/
    _sum?: PaymentAttemptSumAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the minimum value
    **/
    _min?: PaymentAttemptMinAggregateInputType;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     *
     * Select which fields to find the maximum value
    **/
    _max?: PaymentAttemptMaxAggregateInputType;
};
export type GetPaymentAttemptAggregateType<T extends PaymentAttemptAggregateArgs> = {
    [P in keyof T & keyof AggregatePaymentAttempt]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregatePaymentAttempt[P]> : Prisma.GetScalarType<T[P], AggregatePaymentAttempt[P]>;
};
export type PaymentAttemptGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.PaymentAttemptWhereInput;
    orderBy?: Prisma.PaymentAttemptOrderByWithAggregationInput | Prisma.PaymentAttemptOrderByWithAggregationInput[];
    by: Prisma.PaymentAttemptScalarFieldEnum[] | Prisma.PaymentAttemptScalarFieldEnum;
    having?: Prisma.PaymentAttemptScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: PaymentAttemptCountAggregateInputType | true;
    _avg?: PaymentAttemptAvgAggregateInputType;
    _sum?: PaymentAttemptSumAggregateInputType;
    _min?: PaymentAttemptMinAggregateInputType;
    _max?: PaymentAttemptMaxAggregateInputType;
};
export type PaymentAttemptGroupByOutputType = {
    id: string;
    paymentId: string;
    amountInPaise: number;
    status: $Enums.PaymentAttemptStatus;
    gatewayOrderId: string | null;
    gatewayPaymentId: string | null;
    gatewaySignature: string | null;
    gatewayOrderCreatedAt: Date | null;
    gatewayOrderCreationToken: string | null;
    gatewayOrderCreationUntil: Date | null;
    createdAt: Date;
    updatedAt: Date;
    _count: PaymentAttemptCountAggregateOutputType | null;
    _avg: PaymentAttemptAvgAggregateOutputType | null;
    _sum: PaymentAttemptSumAggregateOutputType | null;
    _min: PaymentAttemptMinAggregateOutputType | null;
    _max: PaymentAttemptMaxAggregateOutputType | null;
};
export type GetPaymentAttemptGroupByPayload<T extends PaymentAttemptGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<PaymentAttemptGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof PaymentAttemptGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], PaymentAttemptGroupByOutputType[P]> : Prisma.GetScalarType<T[P], PaymentAttemptGroupByOutputType[P]>;
}>>;
export type PaymentAttemptWhereInput = {
    AND?: Prisma.PaymentAttemptWhereInput | Prisma.PaymentAttemptWhereInput[];
    OR?: Prisma.PaymentAttemptWhereInput[];
    NOT?: Prisma.PaymentAttemptWhereInput | Prisma.PaymentAttemptWhereInput[];
    id?: Prisma.StringFilter<"PaymentAttempt"> | string;
    paymentId?: Prisma.StringFilter<"PaymentAttempt"> | string;
    amountInPaise?: Prisma.IntFilter<"PaymentAttempt"> | number;
    status?: Prisma.EnumPaymentAttemptStatusFilter<"PaymentAttempt"> | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayPaymentId?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewaySignature?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreatedAt?: Prisma.DateTimeNullableFilter<"PaymentAttempt"> | Date | string | null;
    gatewayOrderCreationToken?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreationUntil?: Prisma.DateTimeNullableFilter<"PaymentAttempt"> | Date | string | null;
    createdAt?: Prisma.DateTimeFilter<"PaymentAttempt"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"PaymentAttempt"> | Date | string;
    payment?: Prisma.XOR<Prisma.PaymentScalarRelationFilter, Prisma.PaymentWhereInput>;
};
export type PaymentAttemptOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayOrderId?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewaySignature?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayOrderCreatedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayOrderCreationToken?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayOrderCreationUntil?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    payment?: Prisma.PaymentOrderByWithRelationInput;
};
export type PaymentAttemptWhereUniqueInput = Prisma.AtLeast<{
    id?: string;
    gatewayOrderId?: string;
    gatewayPaymentId?: string;
    AND?: Prisma.PaymentAttemptWhereInput | Prisma.PaymentAttemptWhereInput[];
    OR?: Prisma.PaymentAttemptWhereInput[];
    NOT?: Prisma.PaymentAttemptWhereInput | Prisma.PaymentAttemptWhereInput[];
    paymentId?: Prisma.StringFilter<"PaymentAttempt"> | string;
    amountInPaise?: Prisma.IntFilter<"PaymentAttempt"> | number;
    status?: Prisma.EnumPaymentAttemptStatusFilter<"PaymentAttempt"> | $Enums.PaymentAttemptStatus;
    gatewaySignature?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreatedAt?: Prisma.DateTimeNullableFilter<"PaymentAttempt"> | Date | string | null;
    gatewayOrderCreationToken?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreationUntil?: Prisma.DateTimeNullableFilter<"PaymentAttempt"> | Date | string | null;
    createdAt?: Prisma.DateTimeFilter<"PaymentAttempt"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"PaymentAttempt"> | Date | string;
    payment?: Prisma.XOR<Prisma.PaymentScalarRelationFilter, Prisma.PaymentWhereInput>;
}, "id" | "gatewayOrderId" | "gatewayPaymentId">;
export type PaymentAttemptOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayOrderId?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewaySignature?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayOrderCreatedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayOrderCreationToken?: Prisma.SortOrderInput | Prisma.SortOrder;
    gatewayOrderCreationUntil?: Prisma.SortOrderInput | Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    _count?: Prisma.PaymentAttemptCountOrderByAggregateInput;
    _avg?: Prisma.PaymentAttemptAvgOrderByAggregateInput;
    _max?: Prisma.PaymentAttemptMaxOrderByAggregateInput;
    _min?: Prisma.PaymentAttemptMinOrderByAggregateInput;
    _sum?: Prisma.PaymentAttemptSumOrderByAggregateInput;
};
export type PaymentAttemptScalarWhereWithAggregatesInput = {
    AND?: Prisma.PaymentAttemptScalarWhereWithAggregatesInput | Prisma.PaymentAttemptScalarWhereWithAggregatesInput[];
    OR?: Prisma.PaymentAttemptScalarWhereWithAggregatesInput[];
    NOT?: Prisma.PaymentAttemptScalarWhereWithAggregatesInput | Prisma.PaymentAttemptScalarWhereWithAggregatesInput[];
    id?: Prisma.StringWithAggregatesFilter<"PaymentAttempt"> | string;
    paymentId?: Prisma.StringWithAggregatesFilter<"PaymentAttempt"> | string;
    amountInPaise?: Prisma.IntWithAggregatesFilter<"PaymentAttempt"> | number;
    status?: Prisma.EnumPaymentAttemptStatusWithAggregatesFilter<"PaymentAttempt"> | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.StringNullableWithAggregatesFilter<"PaymentAttempt"> | string | null;
    gatewayPaymentId?: Prisma.StringNullableWithAggregatesFilter<"PaymentAttempt"> | string | null;
    gatewaySignature?: Prisma.StringNullableWithAggregatesFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreatedAt?: Prisma.DateTimeNullableWithAggregatesFilter<"PaymentAttempt"> | Date | string | null;
    gatewayOrderCreationToken?: Prisma.StringNullableWithAggregatesFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreationUntil?: Prisma.DateTimeNullableWithAggregatesFilter<"PaymentAttempt"> | Date | string | null;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"PaymentAttempt"> | Date | string;
    updatedAt?: Prisma.DateTimeWithAggregatesFilter<"PaymentAttempt"> | Date | string;
};
export type PaymentAttemptCreateInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.PaymentAttemptStatus;
    gatewayOrderId?: string | null;
    gatewayPaymentId?: string | null;
    gatewaySignature?: string | null;
    gatewayOrderCreatedAt?: Date | string | null;
    gatewayOrderCreationToken?: string | null;
    gatewayOrderCreationUntil?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    payment: Prisma.PaymentCreateNestedOneWithoutAttemptsInput;
};
export type PaymentAttemptUncheckedCreateInput = {
    id?: string;
    paymentId: string;
    amountInPaise: number;
    status?: $Enums.PaymentAttemptStatus;
    gatewayOrderId?: string | null;
    gatewayPaymentId?: string | null;
    gatewaySignature?: string | null;
    gatewayOrderCreatedAt?: Date | string | null;
    gatewayOrderCreationToken?: string | null;
    gatewayOrderCreationUntil?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type PaymentAttemptUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumPaymentAttemptStatusFieldUpdateOperationsInput | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewaySignature?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreatedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    gatewayOrderCreationToken?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreationUntil?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    payment?: Prisma.PaymentUpdateOneRequiredWithoutAttemptsNestedInput;
};
export type PaymentAttemptUncheckedUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    paymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumPaymentAttemptStatusFieldUpdateOperationsInput | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewaySignature?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreatedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    gatewayOrderCreationToken?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreationUntil?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type PaymentAttemptCreateManyInput = {
    id?: string;
    paymentId: string;
    amountInPaise: number;
    status?: $Enums.PaymentAttemptStatus;
    gatewayOrderId?: string | null;
    gatewayPaymentId?: string | null;
    gatewaySignature?: string | null;
    gatewayOrderCreatedAt?: Date | string | null;
    gatewayOrderCreationToken?: string | null;
    gatewayOrderCreationUntil?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type PaymentAttemptUpdateManyMutationInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumPaymentAttemptStatusFieldUpdateOperationsInput | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewaySignature?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreatedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    gatewayOrderCreationToken?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreationUntil?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type PaymentAttemptUncheckedUpdateManyInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    paymentId?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumPaymentAttemptStatusFieldUpdateOperationsInput | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewaySignature?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreatedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    gatewayOrderCreationToken?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreationUntil?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type PaymentAttemptListRelationFilter = {
    every?: Prisma.PaymentAttemptWhereInput;
    some?: Prisma.PaymentAttemptWhereInput;
    none?: Prisma.PaymentAttemptWhereInput;
};
export type PaymentAttemptOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type PaymentAttemptCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayOrderId?: Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    gatewaySignature?: Prisma.SortOrder;
    gatewayOrderCreatedAt?: Prisma.SortOrder;
    gatewayOrderCreationToken?: Prisma.SortOrder;
    gatewayOrderCreationUntil?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type PaymentAttemptAvgOrderByAggregateInput = {
    amountInPaise?: Prisma.SortOrder;
};
export type PaymentAttemptMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayOrderId?: Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    gatewaySignature?: Prisma.SortOrder;
    gatewayOrderCreatedAt?: Prisma.SortOrder;
    gatewayOrderCreationToken?: Prisma.SortOrder;
    gatewayOrderCreationUntil?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type PaymentAttemptMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    paymentId?: Prisma.SortOrder;
    amountInPaise?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    gatewayOrderId?: Prisma.SortOrder;
    gatewayPaymentId?: Prisma.SortOrder;
    gatewaySignature?: Prisma.SortOrder;
    gatewayOrderCreatedAt?: Prisma.SortOrder;
    gatewayOrderCreationToken?: Prisma.SortOrder;
    gatewayOrderCreationUntil?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type PaymentAttemptSumOrderByAggregateInput = {
    amountInPaise?: Prisma.SortOrder;
};
export type PaymentAttemptCreateNestedManyWithoutPaymentInput = {
    create?: Prisma.XOR<Prisma.PaymentAttemptCreateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput> | Prisma.PaymentAttemptCreateWithoutPaymentInput[] | Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput | Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput[];
    createMany?: Prisma.PaymentAttemptCreateManyPaymentInputEnvelope;
    connect?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
};
export type PaymentAttemptUncheckedCreateNestedManyWithoutPaymentInput = {
    create?: Prisma.XOR<Prisma.PaymentAttemptCreateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput> | Prisma.PaymentAttemptCreateWithoutPaymentInput[] | Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput | Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput[];
    createMany?: Prisma.PaymentAttemptCreateManyPaymentInputEnvelope;
    connect?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
};
export type PaymentAttemptUpdateManyWithoutPaymentNestedInput = {
    create?: Prisma.XOR<Prisma.PaymentAttemptCreateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput> | Prisma.PaymentAttemptCreateWithoutPaymentInput[] | Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput | Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput[];
    upsert?: Prisma.PaymentAttemptUpsertWithWhereUniqueWithoutPaymentInput | Prisma.PaymentAttemptUpsertWithWhereUniqueWithoutPaymentInput[];
    createMany?: Prisma.PaymentAttemptCreateManyPaymentInputEnvelope;
    set?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    disconnect?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    delete?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    connect?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    update?: Prisma.PaymentAttemptUpdateWithWhereUniqueWithoutPaymentInput | Prisma.PaymentAttemptUpdateWithWhereUniqueWithoutPaymentInput[];
    updateMany?: Prisma.PaymentAttemptUpdateManyWithWhereWithoutPaymentInput | Prisma.PaymentAttemptUpdateManyWithWhereWithoutPaymentInput[];
    deleteMany?: Prisma.PaymentAttemptScalarWhereInput | Prisma.PaymentAttemptScalarWhereInput[];
};
export type PaymentAttemptUncheckedUpdateManyWithoutPaymentNestedInput = {
    create?: Prisma.XOR<Prisma.PaymentAttemptCreateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput> | Prisma.PaymentAttemptCreateWithoutPaymentInput[] | Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput[];
    connectOrCreate?: Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput | Prisma.PaymentAttemptCreateOrConnectWithoutPaymentInput[];
    upsert?: Prisma.PaymentAttemptUpsertWithWhereUniqueWithoutPaymentInput | Prisma.PaymentAttemptUpsertWithWhereUniqueWithoutPaymentInput[];
    createMany?: Prisma.PaymentAttemptCreateManyPaymentInputEnvelope;
    set?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    disconnect?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    delete?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    connect?: Prisma.PaymentAttemptWhereUniqueInput | Prisma.PaymentAttemptWhereUniqueInput[];
    update?: Prisma.PaymentAttemptUpdateWithWhereUniqueWithoutPaymentInput | Prisma.PaymentAttemptUpdateWithWhereUniqueWithoutPaymentInput[];
    updateMany?: Prisma.PaymentAttemptUpdateManyWithWhereWithoutPaymentInput | Prisma.PaymentAttemptUpdateManyWithWhereWithoutPaymentInput[];
    deleteMany?: Prisma.PaymentAttemptScalarWhereInput | Prisma.PaymentAttemptScalarWhereInput[];
};
export type EnumPaymentAttemptStatusFieldUpdateOperationsInput = {
    set?: $Enums.PaymentAttemptStatus;
};
export type PaymentAttemptCreateWithoutPaymentInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.PaymentAttemptStatus;
    gatewayOrderId?: string | null;
    gatewayPaymentId?: string | null;
    gatewaySignature?: string | null;
    gatewayOrderCreatedAt?: Date | string | null;
    gatewayOrderCreationToken?: string | null;
    gatewayOrderCreationUntil?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type PaymentAttemptUncheckedCreateWithoutPaymentInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.PaymentAttemptStatus;
    gatewayOrderId?: string | null;
    gatewayPaymentId?: string | null;
    gatewaySignature?: string | null;
    gatewayOrderCreatedAt?: Date | string | null;
    gatewayOrderCreationToken?: string | null;
    gatewayOrderCreationUntil?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type PaymentAttemptCreateOrConnectWithoutPaymentInput = {
    where: Prisma.PaymentAttemptWhereUniqueInput;
    create: Prisma.XOR<Prisma.PaymentAttemptCreateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput>;
};
export type PaymentAttemptCreateManyPaymentInputEnvelope = {
    data: Prisma.PaymentAttemptCreateManyPaymentInput | Prisma.PaymentAttemptCreateManyPaymentInput[];
    skipDuplicates?: boolean;
};
export type PaymentAttemptUpsertWithWhereUniqueWithoutPaymentInput = {
    where: Prisma.PaymentAttemptWhereUniqueInput;
    update: Prisma.XOR<Prisma.PaymentAttemptUpdateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedUpdateWithoutPaymentInput>;
    create: Prisma.XOR<Prisma.PaymentAttemptCreateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedCreateWithoutPaymentInput>;
};
export type PaymentAttemptUpdateWithWhereUniqueWithoutPaymentInput = {
    where: Prisma.PaymentAttemptWhereUniqueInput;
    data: Prisma.XOR<Prisma.PaymentAttemptUpdateWithoutPaymentInput, Prisma.PaymentAttemptUncheckedUpdateWithoutPaymentInput>;
};
export type PaymentAttemptUpdateManyWithWhereWithoutPaymentInput = {
    where: Prisma.PaymentAttemptScalarWhereInput;
    data: Prisma.XOR<Prisma.PaymentAttemptUpdateManyMutationInput, Prisma.PaymentAttemptUncheckedUpdateManyWithoutPaymentInput>;
};
export type PaymentAttemptScalarWhereInput = {
    AND?: Prisma.PaymentAttemptScalarWhereInput | Prisma.PaymentAttemptScalarWhereInput[];
    OR?: Prisma.PaymentAttemptScalarWhereInput[];
    NOT?: Prisma.PaymentAttemptScalarWhereInput | Prisma.PaymentAttemptScalarWhereInput[];
    id?: Prisma.StringFilter<"PaymentAttempt"> | string;
    paymentId?: Prisma.StringFilter<"PaymentAttempt"> | string;
    amountInPaise?: Prisma.IntFilter<"PaymentAttempt"> | number;
    status?: Prisma.EnumPaymentAttemptStatusFilter<"PaymentAttempt"> | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayPaymentId?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewaySignature?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreatedAt?: Prisma.DateTimeNullableFilter<"PaymentAttempt"> | Date | string | null;
    gatewayOrderCreationToken?: Prisma.StringNullableFilter<"PaymentAttempt"> | string | null;
    gatewayOrderCreationUntil?: Prisma.DateTimeNullableFilter<"PaymentAttempt"> | Date | string | null;
    createdAt?: Prisma.DateTimeFilter<"PaymentAttempt"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"PaymentAttempt"> | Date | string;
};
export type PaymentAttemptCreateManyPaymentInput = {
    id?: string;
    amountInPaise: number;
    status?: $Enums.PaymentAttemptStatus;
    gatewayOrderId?: string | null;
    gatewayPaymentId?: string | null;
    gatewaySignature?: string | null;
    gatewayOrderCreatedAt?: Date | string | null;
    gatewayOrderCreationToken?: string | null;
    gatewayOrderCreationUntil?: Date | string | null;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type PaymentAttemptUpdateWithoutPaymentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumPaymentAttemptStatusFieldUpdateOperationsInput | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewaySignature?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreatedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    gatewayOrderCreationToken?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreationUntil?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type PaymentAttemptUncheckedUpdateWithoutPaymentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumPaymentAttemptStatusFieldUpdateOperationsInput | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewaySignature?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreatedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    gatewayOrderCreationToken?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreationUntil?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type PaymentAttemptUncheckedUpdateManyWithoutPaymentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    amountInPaise?: Prisma.IntFieldUpdateOperationsInput | number;
    status?: Prisma.EnumPaymentAttemptStatusFieldUpdateOperationsInput | $Enums.PaymentAttemptStatus;
    gatewayOrderId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayPaymentId?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewaySignature?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreatedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    gatewayOrderCreationToken?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    gatewayOrderCreationUntil?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type PaymentAttemptSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayOrderId?: boolean;
    gatewayPaymentId?: boolean;
    gatewaySignature?: boolean;
    gatewayOrderCreatedAt?: boolean;
    gatewayOrderCreationToken?: boolean;
    gatewayOrderCreationUntil?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["paymentAttempt"]>;
export type PaymentAttemptSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayOrderId?: boolean;
    gatewayPaymentId?: boolean;
    gatewaySignature?: boolean;
    gatewayOrderCreatedAt?: boolean;
    gatewayOrderCreationToken?: boolean;
    gatewayOrderCreationUntil?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["paymentAttempt"]>;
export type PaymentAttemptSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayOrderId?: boolean;
    gatewayPaymentId?: boolean;
    gatewaySignature?: boolean;
    gatewayOrderCreatedAt?: boolean;
    gatewayOrderCreationToken?: boolean;
    gatewayOrderCreationUntil?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["paymentAttempt"]>;
export type PaymentAttemptSelectScalar = {
    id?: boolean;
    paymentId?: boolean;
    amountInPaise?: boolean;
    status?: boolean;
    gatewayOrderId?: boolean;
    gatewayPaymentId?: boolean;
    gatewaySignature?: boolean;
    gatewayOrderCreatedAt?: boolean;
    gatewayOrderCreationToken?: boolean;
    gatewayOrderCreationUntil?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
};
export type PaymentAttemptOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "paymentId" | "amountInPaise" | "status" | "gatewayOrderId" | "gatewayPaymentId" | "gatewaySignature" | "gatewayOrderCreatedAt" | "gatewayOrderCreationToken" | "gatewayOrderCreationUntil" | "createdAt" | "updatedAt", ExtArgs["result"]["paymentAttempt"]>;
export type PaymentAttemptInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
};
export type PaymentAttemptIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
};
export type PaymentAttemptIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    payment?: boolean | Prisma.PaymentDefaultArgs<ExtArgs>;
};
export type $PaymentAttemptPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "PaymentAttempt";
    objects: {
        payment: Prisma.$PaymentPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: string;
        paymentId: string;
        amountInPaise: number;
        status: $Enums.PaymentAttemptStatus;
        gatewayOrderId: string | null;
        gatewayPaymentId: string | null;
        gatewaySignature: string | null;
        gatewayOrderCreatedAt: Date | null;
        gatewayOrderCreationToken: string | null;
        gatewayOrderCreationUntil: Date | null;
        createdAt: Date;
        updatedAt: Date;
    }, ExtArgs["result"]["paymentAttempt"]>;
    composites: {};
};
export type PaymentAttemptGetPayload<S extends boolean | null | undefined | PaymentAttemptDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload, S>;
export type PaymentAttemptCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<PaymentAttemptFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: PaymentAttemptCountAggregateInputType | true;
};
export interface PaymentAttemptDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['PaymentAttempt'];
        meta: {
            name: 'PaymentAttempt';
        };
    };
    /**
     * Find zero or one PaymentAttempt that matches the filter.
     * @param {PaymentAttemptFindUniqueArgs} args - Arguments to find a PaymentAttempt
     * @example
     * // Get one PaymentAttempt
     * const paymentAttempt = await prisma.paymentAttempt.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PaymentAttemptFindUniqueArgs>(args: Prisma.SelectSubset<T, PaymentAttemptFindUniqueArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find one PaymentAttempt that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PaymentAttemptFindUniqueOrThrowArgs} args - Arguments to find a PaymentAttempt
     * @example
     * // Get one PaymentAttempt
     * const paymentAttempt = await prisma.paymentAttempt.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PaymentAttemptFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, PaymentAttemptFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first PaymentAttempt that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAttemptFindFirstArgs} args - Arguments to find a PaymentAttempt
     * @example
     * // Get one PaymentAttempt
     * const paymentAttempt = await prisma.paymentAttempt.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PaymentAttemptFindFirstArgs>(args?: Prisma.SelectSubset<T, PaymentAttemptFindFirstArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    /**
     * Find the first PaymentAttempt that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAttemptFindFirstOrThrowArgs} args - Arguments to find a PaymentAttempt
     * @example
     * // Get one PaymentAttempt
     * const paymentAttempt = await prisma.paymentAttempt.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PaymentAttemptFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, PaymentAttemptFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Find zero or more PaymentAttempts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAttemptFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PaymentAttempts
     * const paymentAttempts = await prisma.paymentAttempt.findMany()
     *
     * // Get first 10 PaymentAttempts
     * const paymentAttempts = await prisma.paymentAttempt.findMany({ take: 10 })
     *
     * // Only select the `id`
     * const paymentAttemptWithIdOnly = await prisma.paymentAttempt.findMany({ select: { id: true } })
     *
     */
    findMany<T extends PaymentAttemptFindManyArgs>(args?: Prisma.SelectSubset<T, PaymentAttemptFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    /**
     * Create a PaymentAttempt.
     * @param {PaymentAttemptCreateArgs} args - Arguments to create a PaymentAttempt.
     * @example
     * // Create one PaymentAttempt
     * const PaymentAttempt = await prisma.paymentAttempt.create({
     *   data: {
     *     // ... data to create a PaymentAttempt
     *   }
     * })
     *
     */
    create<T extends PaymentAttemptCreateArgs>(args: Prisma.SelectSubset<T, PaymentAttemptCreateArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Create many PaymentAttempts.
     * @param {PaymentAttemptCreateManyArgs} args - Arguments to create many PaymentAttempts.
     * @example
     * // Create many PaymentAttempts
     * const paymentAttempt = await prisma.paymentAttempt.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     */
    createMany<T extends PaymentAttemptCreateManyArgs>(args?: Prisma.SelectSubset<T, PaymentAttemptCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Create many PaymentAttempts and returns the data saved in the database.
     * @param {PaymentAttemptCreateManyAndReturnArgs} args - Arguments to create many PaymentAttempts.
     * @example
     * // Create many PaymentAttempts
     * const paymentAttempt = await prisma.paymentAttempt.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Create many PaymentAttempts and only return the `id`
     * const paymentAttemptWithIdOnly = await prisma.paymentAttempt.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    createManyAndReturn<T extends PaymentAttemptCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, PaymentAttemptCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    /**
     * Delete a PaymentAttempt.
     * @param {PaymentAttemptDeleteArgs} args - Arguments to delete one PaymentAttempt.
     * @example
     * // Delete one PaymentAttempt
     * const PaymentAttempt = await prisma.paymentAttempt.delete({
     *   where: {
     *     // ... filter to delete one PaymentAttempt
     *   }
     * })
     *
     */
    delete<T extends PaymentAttemptDeleteArgs>(args: Prisma.SelectSubset<T, PaymentAttemptDeleteArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Update one PaymentAttempt.
     * @param {PaymentAttemptUpdateArgs} args - Arguments to update one PaymentAttempt.
     * @example
     * // Update one PaymentAttempt
     * const paymentAttempt = await prisma.paymentAttempt.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    update<T extends PaymentAttemptUpdateArgs>(args: Prisma.SelectSubset<T, PaymentAttemptUpdateArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Delete zero or more PaymentAttempts.
     * @param {PaymentAttemptDeleteManyArgs} args - Arguments to filter PaymentAttempts to delete.
     * @example
     * // Delete a few PaymentAttempts
     * const { count } = await prisma.paymentAttempt.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     *
     */
    deleteMany<T extends PaymentAttemptDeleteManyArgs>(args?: Prisma.SelectSubset<T, PaymentAttemptDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more PaymentAttempts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAttemptUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PaymentAttempts
     * const paymentAttempt = await prisma.paymentAttempt.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     *
     */
    updateMany<T extends PaymentAttemptUpdateManyArgs>(args: Prisma.SelectSubset<T, PaymentAttemptUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    /**
     * Update zero or more PaymentAttempts and returns the data updated in the database.
     * @param {PaymentAttemptUpdateManyAndReturnArgs} args - Arguments to update many PaymentAttempts.
     * @example
     * // Update many PaymentAttempts
     * const paymentAttempt = await prisma.paymentAttempt.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *
     * // Update zero or more PaymentAttempts and only return the `id`
     * const paymentAttemptWithIdOnly = await prisma.paymentAttempt.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     *
     */
    updateManyAndReturn<T extends PaymentAttemptUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, PaymentAttemptUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    /**
     * Create or update one PaymentAttempt.
     * @param {PaymentAttemptUpsertArgs} args - Arguments to update or create a PaymentAttempt.
     * @example
     * // Update or create a PaymentAttempt
     * const paymentAttempt = await prisma.paymentAttempt.upsert({
     *   create: {
     *     // ... data to create a PaymentAttempt
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PaymentAttempt we want to update
     *   }
     * })
     */
    upsert<T extends PaymentAttemptUpsertArgs>(args: Prisma.SelectSubset<T, PaymentAttemptUpsertArgs<ExtArgs>>): Prisma.Prisma__PaymentAttemptClient<runtime.Types.Result.GetResult<Prisma.$PaymentAttemptPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    /**
     * Count the number of PaymentAttempts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAttemptCountArgs} args - Arguments to filter PaymentAttempts to count.
     * @example
     * // Count the number of PaymentAttempts
     * const count = await prisma.paymentAttempt.count({
     *   where: {
     *     // ... the filter for the PaymentAttempts we want to count
     *   }
     * })
    **/
    count<T extends PaymentAttemptCountArgs>(args?: Prisma.Subset<T, PaymentAttemptCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], PaymentAttemptCountAggregateOutputType> : number>;
    /**
     * Allows you to perform aggregations operations on a PaymentAttempt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAttemptAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PaymentAttemptAggregateArgs>(args: Prisma.Subset<T, PaymentAttemptAggregateArgs>): Prisma.PrismaPromise<GetPaymentAttemptAggregateType<T>>;
    /**
     * Group by PaymentAttempt.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PaymentAttemptGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     *
    **/
    groupBy<T extends PaymentAttemptGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: PaymentAttemptGroupByArgs['orderBy'];
    } : {
        orderBy?: PaymentAttemptGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, PaymentAttemptGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPaymentAttemptGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    /**
     * Fields of the PaymentAttempt model
     */
    readonly fields: PaymentAttemptFieldRefs;
}
/**
 * The delegate class that acts as a "Promise-like" for PaymentAttempt.
 * Why is this prefixed with `Prisma__`?
 * Because we want to prevent naming conflicts as mentioned in
 * https://github.com/prisma/prisma-client-js/issues/707
 */
export interface Prisma__PaymentAttemptClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    payment<T extends Prisma.PaymentDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.PaymentDefaultArgs<ExtArgs>>): Prisma.Prisma__PaymentClient<runtime.Types.Result.GetResult<Prisma.$PaymentPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
/**
 * Fields of the PaymentAttempt model
 */
export interface PaymentAttemptFieldRefs {
    readonly id: Prisma.FieldRef<"PaymentAttempt", 'String'>;
    readonly paymentId: Prisma.FieldRef<"PaymentAttempt", 'String'>;
    readonly amountInPaise: Prisma.FieldRef<"PaymentAttempt", 'Int'>;
    readonly status: Prisma.FieldRef<"PaymentAttempt", 'PaymentAttemptStatus'>;
    readonly gatewayOrderId: Prisma.FieldRef<"PaymentAttempt", 'String'>;
    readonly gatewayPaymentId: Prisma.FieldRef<"PaymentAttempt", 'String'>;
    readonly gatewaySignature: Prisma.FieldRef<"PaymentAttempt", 'String'>;
    readonly gatewayOrderCreatedAt: Prisma.FieldRef<"PaymentAttempt", 'DateTime'>;
    readonly gatewayOrderCreationToken: Prisma.FieldRef<"PaymentAttempt", 'String'>;
    readonly gatewayOrderCreationUntil: Prisma.FieldRef<"PaymentAttempt", 'DateTime'>;
    readonly createdAt: Prisma.FieldRef<"PaymentAttempt", 'DateTime'>;
    readonly updatedAt: Prisma.FieldRef<"PaymentAttempt", 'DateTime'>;
}
/**
 * PaymentAttempt findUnique
 */
export type PaymentAttemptFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * Filter, which PaymentAttempt to fetch.
     */
    where: Prisma.PaymentAttemptWhereUniqueInput;
};
/**
 * PaymentAttempt findUniqueOrThrow
 */
export type PaymentAttemptFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * Filter, which PaymentAttempt to fetch.
     */
    where: Prisma.PaymentAttemptWhereUniqueInput;
};
/**
 * PaymentAttempt findFirst
 */
export type PaymentAttemptFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * Filter, which PaymentAttempt to fetch.
     */
    where?: Prisma.PaymentAttemptWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of PaymentAttempts to fetch.
     */
    orderBy?: Prisma.PaymentAttemptOrderByWithRelationInput | Prisma.PaymentAttemptOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for PaymentAttempts.
     */
    cursor?: Prisma.PaymentAttemptWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` PaymentAttempts from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` PaymentAttempts.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of PaymentAttempts.
     */
    distinct?: Prisma.PaymentAttemptScalarFieldEnum | Prisma.PaymentAttemptScalarFieldEnum[];
};
/**
 * PaymentAttempt findFirstOrThrow
 */
export type PaymentAttemptFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * Filter, which PaymentAttempt to fetch.
     */
    where?: Prisma.PaymentAttemptWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of PaymentAttempts to fetch.
     */
    orderBy?: Prisma.PaymentAttemptOrderByWithRelationInput | Prisma.PaymentAttemptOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for searching for PaymentAttempts.
     */
    cursor?: Prisma.PaymentAttemptWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` PaymentAttempts from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` PaymentAttempts.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of PaymentAttempts.
     */
    distinct?: Prisma.PaymentAttemptScalarFieldEnum | Prisma.PaymentAttemptScalarFieldEnum[];
};
/**
 * PaymentAttempt findMany
 */
export type PaymentAttemptFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * Filter, which PaymentAttempts to fetch.
     */
    where?: Prisma.PaymentAttemptWhereInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     *
     * Determine the order of PaymentAttempts to fetch.
     */
    orderBy?: Prisma.PaymentAttemptOrderByWithRelationInput | Prisma.PaymentAttemptOrderByWithRelationInput[];
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     *
     * Sets the position for listing PaymentAttempts.
     */
    cursor?: Prisma.PaymentAttemptWhereUniqueInput;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Take `±n` PaymentAttempts from the position of the cursor.
     */
    take?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     *
     * Skip the first `n` PaymentAttempts.
     */
    skip?: number;
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     *
     * Filter by unique combinations of PaymentAttempts.
     */
    distinct?: Prisma.PaymentAttemptScalarFieldEnum | Prisma.PaymentAttemptScalarFieldEnum[];
};
/**
 * PaymentAttempt create
 */
export type PaymentAttemptCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * The data needed to create a PaymentAttempt.
     */
    data: Prisma.XOR<Prisma.PaymentAttemptCreateInput, Prisma.PaymentAttemptUncheckedCreateInput>;
};
/**
 * PaymentAttempt createMany
 */
export type PaymentAttemptCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to create many PaymentAttempts.
     */
    data: Prisma.PaymentAttemptCreateManyInput | Prisma.PaymentAttemptCreateManyInput[];
    skipDuplicates?: boolean;
};
/**
 * PaymentAttempt createManyAndReturn
 */
export type PaymentAttemptCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelectCreateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * The data used to create many PaymentAttempts.
     */
    data: Prisma.PaymentAttemptCreateManyInput | Prisma.PaymentAttemptCreateManyInput[];
    skipDuplicates?: boolean;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptIncludeCreateManyAndReturn<ExtArgs> | null;
};
/**
 * PaymentAttempt update
 */
export type PaymentAttemptUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * The data needed to update a PaymentAttempt.
     */
    data: Prisma.XOR<Prisma.PaymentAttemptUpdateInput, Prisma.PaymentAttemptUncheckedUpdateInput>;
    /**
     * Choose, which PaymentAttempt to update.
     */
    where: Prisma.PaymentAttemptWhereUniqueInput;
};
/**
 * PaymentAttempt updateMany
 */
export type PaymentAttemptUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * The data used to update PaymentAttempts.
     */
    data: Prisma.XOR<Prisma.PaymentAttemptUpdateManyMutationInput, Prisma.PaymentAttemptUncheckedUpdateManyInput>;
    /**
     * Filter which PaymentAttempts to update
     */
    where?: Prisma.PaymentAttemptWhereInput;
    /**
     * Limit how many PaymentAttempts to update.
     */
    limit?: number;
};
/**
 * PaymentAttempt updateManyAndReturn
 */
export type PaymentAttemptUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelectUpdateManyAndReturn<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * The data used to update PaymentAttempts.
     */
    data: Prisma.XOR<Prisma.PaymentAttemptUpdateManyMutationInput, Prisma.PaymentAttemptUncheckedUpdateManyInput>;
    /**
     * Filter which PaymentAttempts to update
     */
    where?: Prisma.PaymentAttemptWhereInput;
    /**
     * Limit how many PaymentAttempts to update.
     */
    limit?: number;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptIncludeUpdateManyAndReturn<ExtArgs> | null;
};
/**
 * PaymentAttempt upsert
 */
export type PaymentAttemptUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * The filter to search for the PaymentAttempt to update in case it exists.
     */
    where: Prisma.PaymentAttemptWhereUniqueInput;
    /**
     * In case the PaymentAttempt found by the `where` argument doesn't exist, create a new PaymentAttempt with this data.
     */
    create: Prisma.XOR<Prisma.PaymentAttemptCreateInput, Prisma.PaymentAttemptUncheckedCreateInput>;
    /**
     * In case the PaymentAttempt was found with the provided `where` argument, update it with this data.
     */
    update: Prisma.XOR<Prisma.PaymentAttemptUpdateInput, Prisma.PaymentAttemptUncheckedUpdateInput>;
};
/**
 * PaymentAttempt delete
 */
export type PaymentAttemptDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
    /**
     * Filter which PaymentAttempt to delete.
     */
    where: Prisma.PaymentAttemptWhereUniqueInput;
};
/**
 * PaymentAttempt deleteMany
 */
export type PaymentAttemptDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Filter which PaymentAttempts to delete
     */
    where?: Prisma.PaymentAttemptWhereInput;
    /**
     * Limit how many PaymentAttempts to delete.
     */
    limit?: number;
};
/**
 * PaymentAttempt without action
 */
export type PaymentAttemptDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PaymentAttempt
     */
    select?: Prisma.PaymentAttemptSelect<ExtArgs> | null;
    /**
     * Omit specific fields from the PaymentAttempt
     */
    omit?: Prisma.PaymentAttemptOmit<ExtArgs> | null;
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: Prisma.PaymentAttemptInclude<ExtArgs> | null;
};
//# sourceMappingURL=PaymentAttempt.d.ts.map