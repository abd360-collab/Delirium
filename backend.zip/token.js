import { createHash } from "node:crypto";
export function hashToken(token) {
    return createHash("sha256")
        .update(token)
        .digest("hex");
}
//# sourceMappingURL=token.js.map