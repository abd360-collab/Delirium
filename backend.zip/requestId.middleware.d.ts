import type { Request, Response, NextFunction } from "express";
export declare const requestIdMiddleware: (req: Request, res: Response, next: NextFunction) => void;
//# sourceMappingURL=requestId.middleware.d.ts.map